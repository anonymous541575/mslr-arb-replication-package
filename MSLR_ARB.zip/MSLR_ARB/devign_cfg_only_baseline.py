import os
import copy
import math
import random
import warnings
import argparse
import pickle
import re
from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
from gensim.models import Word2Vec
from imblearn.over_sampling import RandomOverSampler
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, matthews_corrcoef
)
from sklearn.model_selection import StratifiedKFold

import torch
import torch.nn as nn
import torch.nn.functional as F

@dataclass
class Config:
    data_path: str = "mysql_joern_multirel_func.pkl"
    n_splits: int = 5
    epochs: int = 100
    lr: float = 1e-4
    weight_decay: float = 1e-4
    threshold_mode: str = "fixed"
    threshold: float = 0.5
    inner_val_ratio: float = 0.125

    # Devign-style model settings
    word2vec_dim: int = 100
    type_embed_dim: int = 32
    hidden_dim: int = 200
    time_steps: int = 6
    conv_channels: int = 128
    dropout: float = 0.20

    # word2vec training
    w2v_window: int = 5
    w2v_min_count: int = 1
    w2v_workers: int = 1
    w2v_epochs: int = 20

    # train tricks aligned with user's protocol
    grad_clip: float = 2.0
    max_nodes: int = 500
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


CFG = Config()

parser = argparse.ArgumentParser()
parser.add_argument("--data_path", type=str, default=CFG.data_path)
parser.add_argument("--n_splits", type=int, default=CFG.n_splits)
parser.add_argument("--epochs", type=int, default=CFG.epochs)
parser.add_argument("--lr", type=float, default=CFG.lr)
parser.add_argument("--weight_decay", type=float, default=CFG.weight_decay)
parser.add_argument("--threshold_mode", type=str, default=CFG.threshold_mode, choices=["fixed", "search"])
parser.add_argument("--threshold", type=float, default=CFG.threshold)
parser.add_argument("--inner_val_ratio", type=float, default=CFG.inner_val_ratio)
parser.add_argument("--word2vec_dim", type=int, default=CFG.word2vec_dim)
parser.add_argument("--type_embed_dim", type=int, default=CFG.type_embed_dim)
parser.add_argument("--hidden_dim", type=int, default=CFG.hidden_dim)
parser.add_argument("--time_steps", type=int, default=CFG.time_steps)
parser.add_argument("--conv_channels", type=int, default=CFG.conv_channels)
parser.add_argument("--dropout", type=float, default=CFG.dropout)
parser.add_argument("--max_nodes", type=int, default=CFG.max_nodes)
args = parser.parse_args()

CFG.data_path = args.data_path
CFG.n_splits = args.n_splits
CFG.epochs = args.epochs
CFG.lr = args.lr
CFG.weight_decay = args.weight_decay
CFG.threshold_mode = args.threshold_mode
CFG.threshold = args.threshold
CFG.inner_val_ratio = args.inner_val_ratio
CFG.word2vec_dim = args.word2vec_dim
CFG.type_embed_dim = args.type_embed_dim
CFG.hidden_dim = args.hidden_dim
CFG.time_steps = args.time_steps
CFG.conv_channels = args.conv_channels
CFG.dropout = args.dropout
CFG.max_nodes = args.max_nodes

print(f"Using device: {CFG.device}")
print(f"data_path      = {CFG.data_path}")
print(f"n_splits       = {CFG.n_splits}")
print(f"threshold_mode = {CFG.threshold_mode}")
print(f"threshold      = {CFG.threshold}")
print(f"hidden_dim     = {CFG.hidden_dim}")
print(f"time_steps     = {CFG.time_steps}")
print(f"max_nodes      = {CFG.max_nodes}")


# ============================================================
# Data loading
# ============================================================
with open(CFG.data_path, "rb") as f:
    dataset = pickle.load(f)

aging_data = dataset["aging"]
non_aging_data = dataset["non_aging"]
print(f"🌟 load PKL：aging={len(aging_data)}, non_aging={len(non_aging_data)}")


def normalize_filename_for_group(name: str) -> str:
    return os.path.basename(str(name)).replace('\\', '/').split('/')[-1].strip().lower()


def extract_prefix_from_sample_key(sample_key: str) -> str:
    sample_key = str(sample_key)
    return sample_key.split('_', 1)[0] if '_' in sample_key else 'NA'


def build_group_key(sample_key: str, filename: str) -> str:
    prefix = extract_prefix_from_sample_key(sample_key)
    fname = normalize_filename_for_group(filename)
    return f"{prefix}::{fname}"


def tokenize_code(s: str) -> List[str]:
    s = str(s or "")
    toks = re.findall(r"[A-Za-z_][A-Za-z0-9_]*|\d+|==|!=|<=|>=|->|\+\+|--|&&|\|\||[-+*/%=<>{}\[\]().,;:!&|^~?]", s)
    return toks if toks else ["<empty>"]


class GraphSample:
    def __init__(self, node_ids, node_texts, edge_index, label, sample_key, filename):
        self.node_ids = node_ids              # torch.LongTensor [N]
        self.node_texts = node_texts          # list[str], len=N
        self.edge_index = edge_index          # torch.LongTensor [2, E]
        self.label = label                    # torch.FloatTensor scalar
        self.sample_key = sample_key
        self.filename = filename



def build_graph_sample(nodes, texts, edges, label, sample_key, filename):
    nodes = np.asarray(nodes, dtype=np.int64)
    edges = np.asarray(edges, dtype=np.int64)
    texts = list(texts)

    if len(nodes) == 0:
        node_ids = torch.zeros((1,), dtype=torch.long)
        edge_index = torch.zeros((2, 0), dtype=torch.long)
        texts = ["<empty>"]
    else:
        node_ids = torch.tensor(nodes, dtype=torch.long)
        if edges.ndim == 2 and edges.shape[0] > 0:
            edge_index = torch.tensor(edges[:, :2].T, dtype=torch.long)
        else:
            edge_index = torch.zeros((2, 0), dtype=torch.long)
        if len(texts) != len(nodes):
            texts = ["<empty>"] * len(nodes)
    return GraphSample(node_ids, texts, edge_index, torch.tensor(float(label), dtype=torch.float32), str(sample_key), str(filename))



def build_samples():
    samples, labels, group_keys = [], [], []

    def resolve_cfg_fields(g: Dict):
        if all(k in g for k in ["cfg_nodes", "cfg_edges", "cfg_texts"]):
            return "cfg_nodes", "cfg_edges", "cfg_texts"
        if all(k in g for k in ["rel_cfg_nodes", "rel_cfg_edges", "rel_cfg_texts"]):
            return "rel_cfg_nodes", "rel_cfg_edges", "rel_cfg_texts"
        return None

    def consume(data_dict, label):
        loaded = 0
        skipped = 0
        for key, g in data_dict.items():
            fields = resolve_cfg_fields(g)
            if fields is None:
                skipped += 1
                continue

            node_field, edge_field, text_field = fields
            graph = build_graph_sample(
                g[node_field],
                g[text_field],
                g[edge_field],
                label,
                key,
                g.get("filename", "")
            )
            samples.append(graph)
            labels.append(label)
            group_keys.append(build_group_key(key, g.get("filename", "")))
            loaded += 1

        print(f"label={label} | loaded={loaded} | skipped={skipped}")

    consume(aging_data, 1)
    consume(non_aging_data, 0)

    print(f"✅ build_samples done | total={len(samples)} | pos={sum(labels)} | neg={len(labels)-sum(labels)}")

    return samples, np.array(labels, dtype=np.int32), np.array(group_keys, dtype=object)


all_samples, labels_all, group_keys_all = build_samples()
VOCAB_SIZE = 0
for s in all_samples:
    if s.node_ids.numel() > 0:
        VOCAB_SIZE = max(VOCAB_SIZE, int(s.node_ids.max().item()))
VOCAB_SIZE += 1
print(f"✅ Built CFG-only samples: {len(all_samples)} | node_vocab={VOCAB_SIZE}")


# ============================================================
# Split / metrics utilities (copied in spirit from user's script)
# ============================================================

def truncate_graph_by_degree(graph: GraphSample, max_nodes: int) -> GraphSample:
    if max_nodes <= 0:
        return graph
    num_nodes = int(graph.node_ids.numel())
    if num_nodes <= max_nodes:
        return graph

    edge_index = graph.edge_index
    node_ids = graph.node_ids
    node_texts = graph.node_texts
    deg = torch.zeros(num_nodes, dtype=torch.long)
    if edge_index.numel() > 0:
        src = edge_index[0]
        dst = edge_index[1]
        valid = (src >= 0) & (src < num_nodes) & (dst >= 0) & (dst < num_nodes)
        src = src[valid]
        dst = dst[valid]
        deg.index_add_(0, src, torch.ones_like(src))
        deg.index_add_(0, dst, torch.ones_like(dst))

    scores = deg.numpy()
    order = np.lexsort((np.arange(num_nodes), -scores))
    keep_nodes = np.sort(order[:max_nodes])
    keep_nodes_t = torch.tensor(keep_nodes, dtype=torch.long)

    remap = -torch.ones(num_nodes, dtype=torch.long)
    remap[keep_nodes_t] = torch.arange(len(keep_nodes_t), dtype=torch.long)
    if edge_index.numel() > 0:
        src = edge_index[0]
        dst = edge_index[1]
        keep_mask = (remap[src] >= 0) & (remap[dst] >= 0)
        new_src = remap[src[keep_mask]]
        new_dst = remap[dst[keep_mask]]
        new_edge_index = torch.stack([new_src, new_dst], dim=0)
    else:
        new_edge_index = torch.zeros((2, 0), dtype=torch.long)

    new_texts = [node_texts[i] for i in keep_nodes.tolist()]
    return GraphSample(node_ids[keep_nodes_t], new_texts, new_edge_index, graph.label.clone(), graph.sample_key, graph.filename)



def build_dense_adj(num_nodes: int, edge_index: torch.Tensor, device: str):
    A = torch.zeros((num_nodes, num_nodes), dtype=torch.float32, device=device)
    if edge_index.numel() > 0:
        src = edge_index[0].to(device)
        dst = edge_index[1].to(device)
        valid = (src >= 0) & (src < num_nodes) & (dst >= 0) & (dst < num_nodes)
        src = src[valid]
        dst = dst[valid]
        A[src, dst] = 1.0
    A = A + torch.eye(num_nodes, device=device)
    deg = A.sum(dim=-1, keepdim=True).clamp(min=1.0)
    return A / deg



def compute_balance(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    pf = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    return 1 - (math.sqrt((0 - pf) ** 2 + (1 - rec) ** 2) / math.sqrt(2))



def compute_metrics(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.5
    balance = compute_balance(y_true, y_pred)
    try:
        mcc = matthews_corrcoef(y_true, y_pred)
    except Exception:
        mcc = 0.0
    return {"pre": float(precision), "rec": float(recall), "f1": float(f1), "auc": float(auc), "balance": float(balance), "mcc": float(mcc)}



def build_group_level_arrays(group_keys, y_all):
    group_to_indices = {}
    for idx, gk in enumerate(group_keys):
        group_to_indices.setdefault(str(gk), []).append(idx)
    unique_groups = np.array(sorted(group_to_indices.keys()), dtype=object)
    group_labels = []
    for gk in unique_groups:
        idxs = group_to_indices[gk]
        labels = y_all[idxs]
        if not np.all(labels == labels[0]):
            raise ValueError(f" {gk} ")
        group_labels.append(int(labels[0]))
    return group_to_indices, unique_groups, np.array(group_labels, dtype=np.int32)



def groups_to_sample_indices(groups, group_to_indices):
    out = []
    for gk in groups:
        out.extend(group_to_indices[str(gk)])
    return np.array(sorted(out), dtype=np.int32)



def build_group_folds(group_keys, y_all, n_splits, seed):
    group_to_indices, unique_groups, group_labels = build_group_level_arrays(group_keys, y_all)
    pos_groups = int((group_labels == 1).sum())
    neg_groups = int((group_labels == 0).sum())
    max_valid_splits = min(n_splits, pos_groups, neg_groups)
    skf = StratifiedKFold(n_splits=max_valid_splits, shuffle=True, random_state=seed)
    folds = []
    for train_group_idx, test_group_idx in skf.split(unique_groups, group_labels):
        train_groups = unique_groups[train_group_idx]
        test_groups = unique_groups[test_group_idx]
        idx_train = groups_to_sample_indices(train_groups, group_to_indices)
        idx_test = groups_to_sample_indices(test_groups, group_to_indices)
        folds.append((idx_train, idx_test, train_groups, test_groups))
    return folds, group_to_indices, unique_groups, group_labels



def split_train_val_from_outer_train_grouped(train_groups, group_to_indices, group_labels_map, seed):
    train_groups = np.array(list(train_groups), dtype=object)
    y_groups = np.array([group_labels_map[str(g)] for g in train_groups], dtype=np.int32)
    desired_val_groups = max(1, int(round(len(train_groups) * CFG.inner_val_ratio)))
    max_valid = min((y_groups == 1).sum(), (y_groups == 0).sum())
    if max_valid >= 2 and len(train_groups) >= 4 and desired_val_groups >= 1:
        n_splits_inner = min(max(2, int(round(1.0 / max(CFG.inner_val_ratio, 1e-6)))), max_valid, len(train_groups))
        skf_inner = StratifiedKFold(n_splits=n_splits_inner, shuffle=True, random_state=seed)
        inner_train_idx, inner_val_idx = next(skf_inner.split(train_groups, y_groups))
        return groups_to_sample_indices(train_groups[inner_train_idx], group_to_indices), groups_to_sample_indices(train_groups[inner_val_idx], group_to_indices)

    pos_groups = train_groups[y_groups == 1].tolist()
    neg_groups = train_groups[y_groups == 0].tolist()
    rnd = random.Random(seed)
    rnd.shuffle(pos_groups)
    rnd.shuffle(neg_groups)
    n_pos_val = max(1, int(round(len(pos_groups) * CFG.inner_val_ratio))) if len(pos_groups) >= 2 else 0
    n_neg_val = max(1, int(round(len(neg_groups) * CFG.inner_val_ratio))) if len(neg_groups) >= 2 else 0
    val_groups = pos_groups[:n_pos_val] + neg_groups[:n_neg_val]
    train_split_groups = pos_groups[n_pos_val:] + neg_groups[n_neg_val:]
    return groups_to_sample_indices(train_split_groups, group_to_indices), groups_to_sample_indices(val_groups, group_to_indices)



def make_ros_indices(idx_train, y_all, seed):
    y_train = y_all[idx_train]
    local_idx = np.arange(len(idx_train)).reshape(-1, 1)
    ros = RandomOverSampler(random_state=seed)
    local_idx_ros, _ = ros.fit_resample(local_idx, y_train)
    return idx_train[local_idx_ros.flatten()]



def find_best_threshold(y_true, y_prob):
    best_threshold, best_metrics, best_key = 0.5, None, (-1.0, -1.0, -1.0)
    for threshold in np.arange(0.001, 0.999, 0.05):
        metrics = compute_metrics(y_true, y_prob, threshold=float(threshold))
        key = (metrics["f1"], metrics["mcc"], metrics["auc"])
        if key > best_key:
            best_key, best_threshold, best_metrics = key, float(threshold), metrics
    return best_threshold, best_metrics


GROUP_FOLDS, GROUP_TO_INDICES, UNIQUE_GROUPS, GROUP_LABELS = build_group_folds(group_keys_all, labels_all, CFG.n_splits, 5)
GROUP_LABEL_MAP = {str(g): int(y) for g, y in zip(UNIQUE_GROUPS, GROUP_LABELS)}

# ============================================================
# Word2Vec feature extraction
# ============================================================

def train_fold_word2vec(train_samples: List[GraphSample]) -> Word2Vec:
    sentences = []
    for s in train_samples:
        for txt in s.node_texts:
            sentences.append(tokenize_code(txt))
    model = Word2Vec(
        sentences=sentences,
        vector_size=CFG.word2vec_dim,
        window=CFG.w2v_window,
        min_count=CFG.w2v_min_count,
        workers=CFG.w2v_workers,
        sg=1,
        epochs=CFG.w2v_epochs,
        seed=5,
    )
    return model



def encode_node_texts_w2v(node_texts: List[str], w2v_model: Word2Vec) -> torch.Tensor:
    vecs = []
    wv = w2v_model.wv
    for txt in node_texts:
        toks = tokenize_code(txt)
        arr = [wv[t] for t in toks if t in wv]
        if len(arr) == 0:
            vec = np.zeros((CFG.word2vec_dim,), dtype=np.float32)
        else:
            vec = np.mean(np.asarray(arr, dtype=np.float32), axis=0)
        vecs.append(vec)
    return torch.tensor(np.asarray(vecs, dtype=np.float32), dtype=torch.float32)


# ============================================================
# Devign model
# ============================================================
class GGNNLayer(nn.Module):
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.msg = nn.Linear(hidden_dim, hidden_dim)
        self.gru = nn.GRUCell(hidden_dim, hidden_dim)

    def forward(self, h: torch.Tensor, A_hat: torch.Tensor) -> torch.Tensor:
        neigh = A_hat @ self.msg(h)
        return self.gru(neigh, h)


class DevignCFGOnlyModel(nn.Module):
    def __init__(self, vocab_size: int):
        super().__init__()
        self.type_emb = nn.Embedding(vocab_size, CFG.type_embed_dim)
        self.input_proj = nn.Linear(CFG.type_embed_dim + CFG.word2vec_dim, CFG.hidden_dim)
        self.ggnn_layers = nn.ModuleList([GGNNLayer(CFG.hidden_dim) for _ in range(CFG.time_steps)])
        self.drop = nn.Dropout(CFG.dropout)

        # Devign conv module approximation with graph-level 1D conv stack
        self.conv_z1 = nn.Conv1d(CFG.hidden_dim * 2, CFG.conv_channels, kernel_size=3, padding=1)
        self.conv_z2 = nn.Conv1d(CFG.conv_channels, CFG.conv_channels, kernel_size=1)
        self.conv_y1 = nn.Conv1d(CFG.hidden_dim, CFG.conv_channels, kernel_size=3, padding=1)
        self.conv_y2 = nn.Conv1d(CFG.conv_channels, CFG.conv_channels, kernel_size=1)

        self.mlp_z = nn.Linear(CFG.conv_channels, 1)
        self.mlp_y = nn.Linear(CFG.conv_channels, 1)

    def forward(self, graph: GraphSample, node_text_feat: torch.Tensor):
        node_ids = graph.node_ids.to(CFG.device)
        edge_index = graph.edge_index.to(CFG.device)
        text_feat = node_text_feat.to(CFG.device)

        type_feat = self.type_emb(node_ids)
        x = torch.cat([type_feat, text_feat], dim=-1)
        x = self.input_proj(x)
        x = F.relu(x)
        x0 = x

        A_hat = build_dense_adj(x.size(0), edge_index, CFG.device)
        h = x
        for layer in self.ggnn_layers:
            h = layer(h, A_hat)
            h = F.relu(h)
            h = self.drop(h)

        # [1, C, N]
        z = torch.cat([h, x0], dim=-1).transpose(0, 1).unsqueeze(0)
        y = h.transpose(0, 1).unsqueeze(0)

        z = F.relu(self.conv_z1(z))
        z = F.max_pool1d(z, kernel_size=2, stride=2, ceil_mode=True)
        z = F.relu(self.conv_z2(z))
        z = F.max_pool1d(z, kernel_size=2, stride=2, ceil_mode=True)

        y = F.relu(self.conv_y1(y))
        y = F.max_pool1d(y, kernel_size=2, stride=2, ceil_mode=True)
        y = F.relu(self.conv_y2(y))
        y = F.max_pool1d(y, kernel_size=2, stride=2, ceil_mode=True)

        z_vec = z.mean(dim=-1).squeeze(0)
        y_vec = y.mean(dim=-1).squeeze(0)
        logit = self.mlp_z(z_vec).squeeze(-1) * self.mlp_y(y_vec).squeeze(-1)
        return torch.nan_to_num(logit, nan=0.0, posinf=20.0, neginf=-20.0)


# ============================================================
# Training / evaluation
# ============================================================

def evaluate(model, indices, threshold, text_feat_cache):
    model.eval()
    criterion = nn.BCEWithLogitsLoss()
    all_probs, all_true = [], []
    total_loss = 0.0
    with torch.no_grad():
        for idx in indices:
            sample = truncate_graph_by_degree(all_samples[int(idx)], CFG.max_nodes)
            text_feat = text_feat_cache[sample.sample_key]
            y = sample.label.to(CFG.device).view(1)
            logits = model(sample, text_feat).view(1)
            loss = criterion(logits, y)
            total_loss += loss.item()
            all_probs.append(torch.sigmoid(logits).item())
            all_true.append(float(sample.label.item()))
    y_prob = np.array(all_probs, dtype=np.float32)
    y_true = np.array(all_true, dtype=np.float32)
    return total_loss / max(len(indices), 1), compute_metrics(y_true, y_prob, threshold), y_true, y_prob



def build_text_feature_cache(samples: List[GraphSample], w2v_model: Word2Vec) -> Dict[str, torch.Tensor]:
    cache = {}
    for s in samples:
        s_trunc = truncate_graph_by_degree(s, CFG.max_nodes)
        cache[s.sample_key] = encode_node_texts_w2v(s_trunc.node_texts, w2v_model)
    return cache

os.environ["PYTHONHASHSEED"] = str(5)
random.seed(5)
np.random.seed(5)
torch.manual_seed(5)
torch.cuda.manual_seed_all(5)
warnings.filterwarnings("ignore")


def reset_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def train_one_fold(fold_id: int, idx_train_full, idx_test, train_groups, test_groups, seed: int):
    reset_seed(seed)
    idx_train_inner, idx_val_inner = split_train_val_from_outer_train_grouped(train_groups, GROUP_TO_INDICES, GROUP_LABEL_MAP, seed)
    idx_train_ros = make_ros_indices(idx_train_inner, labels_all, seed)

    train_samples_for_w2v = [truncate_graph_by_degree(all_samples[int(i)], CFG.max_nodes) for i in idx_train_inner]
    w2v_model = train_fold_word2vec(train_samples_for_w2v)
    text_feat_cache = build_text_feature_cache(all_samples, w2v_model)

    print(
        f"Fold {fold_id:02d} split | "
        f"train groups={len(train_groups)}, val groups={len(set(group_keys_all[idx_val_inner]))}, test groups={len(test_groups)} | "
        f"train pos/neg={int(labels_all[idx_train_inner].sum())}/{int(len(idx_train_inner)-labels_all[idx_train_inner].sum())}, "
        f"val pos/neg={int(labels_all[idx_val_inner].sum())}/{int(len(idx_val_inner)-labels_all[idx_val_inner].sum())}, "
        f"test pos/neg={int(labels_all[idx_test].sum())}/{int(len(idx_test)-labels_all[idx_test].sum())}"
    )

    model = DevignCFGOnlyModel(vocab_size=VOCAB_SIZE).to(CFG.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
    criterion = nn.BCEWithLogitsLoss()

    best_state, best_val_loss, best_epoch = None, float("inf"), -1
    for epoch in range(1, CFG.epochs + 1):
        model.train()
        shuffled = np.random.permutation(idx_train_ros)
        for idx in shuffled:
            sample = truncate_graph_by_degree(all_samples[int(idx)], CFG.max_nodes)
            text_feat = text_feat_cache[sample.sample_key]
            y = sample.label.to(CFG.device).view(1)
            optimizer.zero_grad()
            logits = model(sample, text_feat).view(1)
            loss = criterion(logits, y)
            if torch.isnan(loss) or torch.isinf(loss):
                continue
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), CFG.grad_clip)
            optimizer.step()

        val_loss, _, _, _ = evaluate(model, idx_val_inner, threshold=CFG.threshold, text_feat_cache=text_feat_cache)
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())

    model.load_state_dict(best_state)

    if CFG.threshold_mode == "search":
        _, _, y_val, prob_val = evaluate(model, idx_val_inner, threshold=CFG.threshold, text_feat_cache=text_feat_cache)
        best_threshold, _ = find_best_threshold(y_val, prob_val)
    else:
        best_threshold = CFG.threshold

    _, _, y_test, prob_test = evaluate(model, idx_test, threshold=best_threshold, text_feat_cache=text_feat_cache)
    test_metrics = compute_metrics(y_test, prob_test, threshold=best_threshold)

    print(
        f"Fold {fold_id:02d} | best_epoch={best_epoch:03d} | val_loss={best_val_loss:.4f} | "
        f"thr={best_threshold:.2f} | Precision={test_metrics['pre']:.4f} | "
        f"F1={test_metrics['f1']:.4f} | AUC={test_metrics['auc']:.4f} | "
        f"Balance={test_metrics['balance']:.4f} | MCC={test_metrics['mcc']:.4f}"
    )
    return {"threshold": best_threshold, "test": test_metrics}


all_results = []
print(f"\n🚀 Start {CFG.n_splits}-fold grouped CV with Devign-style CFG-only baseline ...\n")
for fold_id, (idx_train_full, idx_test, train_groups, test_groups) in enumerate(GROUP_FOLDS, start=1):
    all_results.append(train_one_fold(fold_id, idx_train_full, idx_test, train_groups, test_groups, 5 + fold_id))



def summarize(metric_list):
    out = {}
    for key in ["pre", "f1", "auc", "balance", "mcc"]:
        vals = np.array([m[key] for m in metric_list], dtype=np.float64)
        out[key] = (vals.mean(), vals.std(ddof=0))
    return out


summary = summarize([r["test"] for r in all_results])
threshold_vals = np.array([r["threshold"] for r in all_results], dtype=np.float64)

print("\n" + "=" * 72)
print("🏆 Devign-Style CFG-Only 5-Fold CV Summary")
print("=" * 72)
print(f"Threshold   : {threshold_vals.mean():.4f} ± {threshold_vals.std(ddof=0):.4f}")
print(f"Precision   : {summary['pre'][0]:.4f} ± {summary['pre'][1]:.4f}")
print(f"F1-Score    : {summary['f1'][0]:.4f} ± {summary['f1'][1]:.4f}")
print(f"AUC         : {summary['auc'][0]:.4f} ± {summary['auc'][1]:.4f}")
print(f"Balance     : {summary['balance'][0]:.4f} ± {summary['balance'][1]:.4f}")
print(f"MCC         : {summary['mcc'][0]:.4f} ± {summary['mcc'][1]:.4f}")
print("=" * 72)


if __name__ == "__main__":
    pass
