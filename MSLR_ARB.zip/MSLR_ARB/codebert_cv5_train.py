import os
import json
import math
import copy
import random
import warnings
import argparse
from dataclasses import dataclass
from typing import List, Dict, Any

import numpy as np
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, matthews_corrcoef
)
from sklearn.model_selection import StratifiedKFold
from imblearn.over_sampling import RandomOverSampler

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification, get_linear_schedule_with_warmup

# python codebert_cv5_train.py --data_path CodeBERT/linux_codebert_with_code.jsonl
# python codebert_cv5_train.py --data_path CodeBERT/netbsd_codebert_with_code.jsonl
# python codebert_cv5_train.py --data_path CodeBERT/mysql_codebert_with_code.jsonl

@dataclass
class Config:
    data_path: str = "CodeBERT/linux_codebert_with_code.jsonl"
    model_name: str = "microsoft/codebert-base"
    n_splits: int = 5
    epochs: int = 10
    batch_size: int = 8
    eval_batch_size: int = 16
    lr: float = 2e-5
    weight_decay: float = 0.01
    max_length: int = 512
    threshold_mode: str = "fixed"
    threshold: float = 0.5
    inner_val_ratio: float = 0.125
    grad_clip: float = 1.0
    warmup_ratio: float = 0.1
    use_ros: bool = True
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


CFG = Config()

parser = argparse.ArgumentParser()
parser.add_argument("--data_path", type=str, default=CFG.data_path)
parser.add_argument("--model_name", type=str, default=CFG.model_name)
parser.add_argument("--n_splits", type=int, default=CFG.n_splits)
parser.add_argument("--epochs", type=int, default=CFG.epochs)
parser.add_argument("--batch_size", type=int, default=CFG.batch_size)
parser.add_argument("--eval_batch_size", type=int, default=CFG.eval_batch_size)
parser.add_argument("--lr", type=float, default=CFG.lr)
parser.add_argument("--weight_decay", type=float, default=CFG.weight_decay)
parser.add_argument("--max_length", type=int, default=CFG.max_length)
parser.add_argument("--threshold_mode", type=str, default=CFG.threshold_mode, choices=["fixed", "search"])
parser.add_argument("--threshold", type=float, default=CFG.threshold)
parser.add_argument("--inner_val_ratio", type=float, default=CFG.inner_val_ratio)
parser.add_argument("--warmup_ratio", type=float, default=CFG.warmup_ratio)
parser.add_argument("--use_ros", type=int, default=1)
args = parser.parse_args()

CFG.data_path = args.data_path
CFG.model_name = args.model_name
CFG.n_splits = args.n_splits
CFG.epochs = args.epochs
CFG.batch_size = args.batch_size
CFG.eval_batch_size = args.eval_batch_size
CFG.lr = args.lr
CFG.weight_decay = args.weight_decay
CFG.max_length = args.max_length
CFG.threshold_mode = args.threshold_mode
CFG.threshold = args.threshold
CFG.inner_val_ratio = args.inner_val_ratio
CFG.warmup_ratio = args.warmup_ratio
CFG.use_ros = bool(args.use_ros)

print(f"Using device: {CFG.device}")
print(f"data_path      = {CFG.data_path}")
print(f"model_name     = {CFG.model_name}")
print(f"n_splits       = {CFG.n_splits}")
print(f"threshold_mode = {CFG.threshold_mode}")
print(f"threshold      = {CFG.threshold}")
print(f"max_length     = {CFG.max_length}")


def compute_balance(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    pf = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    return 1 - (math.sqrt((0 - pf) ** 2 + (1 - rec) ** 2) / math.sqrt(2))


def compute_metrics(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.5
    balance = compute_balance(y_true, y_pred)
    try:
        mcc = matthews_corrcoef(y_true, y_pred)
    except Exception:
        mcc = 0.0
    return {
        "pre": float(precision),
        "rec": float(recall),
        "f1": float(f1),
        "auc": float(auc),
        "balance": float(balance),
        "mcc": float(mcc),
    }


def find_best_threshold(y_true, y_prob):
    best_threshold, best_metrics, best_key = 0.5, None, (-1.0, -1.0, -1.0)
    for threshold in np.arange(0.001, 0.999, 0.05):
        metrics = compute_metrics(y_true, y_prob, threshold=float(threshold))
        key = (metrics["f1"], metrics["mcc"], metrics["auc"])
        if key > best_key:
            best_key, best_threshold, best_metrics = key, float(threshold), metrics
    return best_threshold, best_metrics


def extract_prefix_from_sample_key(sample_key: str) -> str:
    sample_key = str(sample_key)
    return sample_key.split('_', 1)[0] if '_' in sample_key else 'NA'


def normalize_filename_for_group(name: str) -> str:
    return os.path.basename(str(name)).replace('\\', '/').split('/')[-1].strip().lower()


def build_group_key(sample_key: str, filename: str) -> str:
    prefix = extract_prefix_from_sample_key(sample_key)
    fname = normalize_filename_for_group(filename)
    return f"{prefix}::{fname}"


class CodeSample:
    def __init__(self, sample_key: str, filename: str, code: str, label: int, group_key: str):
        self.sample_key = sample_key
        self.filename = filename
        self.code = code
        self.label = int(label)
        self.group_key = group_key


class JsonlCodeDataset(Dataset):
    def __init__(self, samples: List[CodeSample], tokenizer, max_length: int):
        self.samples = samples
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int):
        s = self.samples[idx]
        return {
            "code": s.code,
            "label": s.label,
            "sample_key": s.sample_key,
        }

    def collate_fn(self, batch: List[Dict[str, Any]]):
        codes = [x["code"] for x in batch]
        labels = torch.tensor([x["label"] for x in batch], dtype=torch.long)
        enc = self.tokenizer(
            codes,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )
        enc["labels"] = labels
        return enc


def load_jsonl_samples(path: str) -> List[CodeSample]:
    samples = []
    total = 0
    skipped = 0

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            obj = json.loads(line)

            status = str(obj.get("status", "ok")).strip().lower()
            code = str(obj.get("code", ""))
            label = obj.get("label", None)
            sample_key = str(obj.get("sample_key", ""))
            filename = str(obj.get("filename", ""))
            group_key = str(obj.get("group_key", "")).strip()

            if label is None:
                skipped += 1
                continue
            if status != "ok":
                skipped += 1
                continue
            if not code or not code.strip():
                skipped += 1
                continue
            if not group_key:
                group_key = build_group_key(sample_key, filename)

            samples.append(CodeSample(
                sample_key=sample_key,
                filename=filename,
                code=code,
                label=int(label),
                group_key=group_key,
            ))

    print(f"🌟 Loaded JSONL: total={total}, usable={len(samples)}, skipped={skipped}")
    return samples


def build_group_level_arrays(group_keys, y_all):
    group_to_indices = {}
    for idx, gk in enumerate(group_keys):
        group_to_indices.setdefault(str(gk), []).append(idx)
    unique_groups = np.array(sorted(group_to_indices.keys()), dtype=object)
    group_labels = []
    for gk in unique_groups:
        idxs = group_to_indices[gk]
        labels = y_all[idxs]
        if not np.all(labels == labels[0]):
            raise ValueError(f" {gk}")
        group_labels.append(int(labels[0]))
    return group_to_indices, unique_groups, np.array(group_labels, dtype=np.int32)


def groups_to_sample_indices(groups, group_to_indices):
    out = []
    for gk in groups:
        out.extend(group_to_indices[str(gk)])
    return np.array(sorted(out), dtype=np.int32)


def build_group_folds(group_keys, y_all, n_splits, seed):
    group_to_indices, unique_groups, group_labels = build_group_level_arrays(group_keys, y_all)
    pos_groups = int((group_labels == 1).sum())
    neg_groups = int((group_labels == 0).sum())
    max_valid_splits = min(n_splits, pos_groups, neg_groups)
    if max_valid_splits < 2:
        raise ValueError(f"The effective positive and negative groups are insufficient for conducting {n_splits}-fold，pos_groups={pos_groups}, neg_groups={neg_groups}")
    skf = StratifiedKFold(n_splits=max_valid_splits, shuffle=True, random_state=seed)
    folds = []
    for train_group_idx, test_group_idx in skf.split(unique_groups, group_labels):
        train_groups = unique_groups[train_group_idx]
        test_groups = unique_groups[test_group_idx]
        idx_train = groups_to_sample_indices(train_groups, group_to_indices)
        idx_test = groups_to_sample_indices(test_groups, group_to_indices)
        folds.append((idx_train, idx_test, train_groups, test_groups))
    return folds, group_to_indices, unique_groups, group_labels


def split_train_val_from_outer_train_grouped(train_groups, group_to_indices, group_labels_map, seed):
    train_groups = np.array(list(train_groups), dtype=object)
    y_groups = np.array([group_labels_map[str(g)] for g in train_groups], dtype=np.int32)
    desired_val_groups = max(1, int(round(len(train_groups) * CFG.inner_val_ratio)))
    max_valid = min((y_groups == 1).sum(), (y_groups == 0).sum())
    if max_valid >= 2 and len(train_groups) >= 4 and desired_val_groups >= 1:
        n_splits_inner = min(max(2, int(round(1.0 / max(CFG.inner_val_ratio, 1e-6)))), max_valid, len(train_groups))
        skf_inner = StratifiedKFold(n_splits=n_splits_inner, shuffle=True, random_state=seed)
        inner_train_idx, inner_val_idx = next(skf_inner.split(train_groups, y_groups))
        return groups_to_sample_indices(train_groups[inner_train_idx], group_to_indices), groups_to_sample_indices(train_groups[inner_val_idx], group_to_indices)

    pos_groups = train_groups[y_groups == 1].tolist()
    neg_groups = train_groups[y_groups == 0].tolist()
    rnd = random.Random(seed)
    rnd.shuffle(pos_groups)
    rnd.shuffle(neg_groups)
    n_pos_val = max(1, int(round(len(pos_groups) * CFG.inner_val_ratio))) if len(pos_groups) >= 2 else 0
    n_neg_val = max(1, int(round(len(neg_groups) * CFG.inner_val_ratio))) if len(neg_groups) >= 2 else 0
    val_groups = pos_groups[:n_pos_val] + neg_groups[:n_neg_val]
    train_split_groups = pos_groups[n_pos_val:] + neg_groups[n_neg_val:]
    return groups_to_sample_indices(train_split_groups, group_to_indices), groups_to_sample_indices(val_groups, group_to_indices)


def make_ros_indices(idx_train, y_all, seed):
    y_train = y_all[idx_train]
    local_idx = np.arange(len(idx_train)).reshape(-1, 1)
    ros = RandomOverSampler(random_state=seed)
    local_idx_ros, _ = ros.fit_resample(local_idx, y_train)
    return idx_train[local_idx_ros.flatten()]


def build_dataloader(samples_all, indices, tokenizer, batch_size, shuffle):
    subset = [samples_all[int(i)] for i in indices]
    ds = JsonlCodeDataset(subset, tokenizer, CFG.max_length)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, collate_fn=ds.collate_fn)


def evaluate(model, dataloader, threshold=0.5):
    model.eval()
    all_probs, all_true = [], []
    total_loss = 0.0
    with torch.no_grad():
        for batch in dataloader:
            batch = {k: v.to(CFG.device) for k, v in batch.items()}
            outputs = model(**batch)
            loss = outputs.loss
            logits = outputs.logits
            probs = torch.softmax(logits, dim=-1)[:, 1]

            total_loss += loss.item() * batch["labels"].size(0)
            all_probs.extend(probs.cpu().numpy().tolist())
            all_true.extend(batch["labels"].cpu().numpy().tolist())

    y_prob = np.array(all_probs, dtype=np.float32)
    y_true = np.array(all_true, dtype=np.float32)
    avg_loss = total_loss / max(len(y_true), 1)
    return avg_loss, compute_metrics(y_true, y_prob, threshold), y_true, y_prob

os.environ["PYTHONHASHSEED"] = str(5)
random.seed(5)
np.random.seed(5)
torch.manual_seed(5)
torch.cuda.manual_seed_all(5)
warnings.filterwarnings("ignore")


def reset_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def train_one_fold(fold_id, samples_all, labels_all, idx_train_full, idx_test, train_groups, test_groups, seed, tokenizer):
    reset_seed(seed)
    idx_train_inner, idx_val_inner = split_train_val_from_outer_train_grouped(train_groups, GROUP_TO_INDICES, GROUP_LABEL_MAP, seed)
    idx_train_ros = make_ros_indices(idx_train_inner, labels_all, seed) if CFG.use_ros else idx_train_inner

    print(
        f"Fold {fold_id:02d} split | "
        f"train groups={len(train_groups)}, val groups={len(set(group_keys_all[idx_val_inner]))}, test groups={len(test_groups)} | "
        f"train pos/neg={int(labels_all[idx_train_inner].sum())}/{int(len(idx_train_inner)-labels_all[idx_train_inner].sum())}, "
        f"val pos/neg={int(labels_all[idx_val_inner].sum())}/{int(len(idx_val_inner)-labels_all[idx_val_inner].sum())}, "
        f"test pos/neg={int(labels_all[idx_test].sum())}/{int(len(idx_test)-labels_all[idx_test].sum())}"
    )

    train_loader = build_dataloader(samples_all, idx_train_ros, tokenizer, CFG.batch_size, shuffle=True)
    val_loader = build_dataloader(samples_all, idx_val_inner, tokenizer, CFG.eval_batch_size, shuffle=False)
    test_loader = build_dataloader(samples_all, idx_test, tokenizer, CFG.eval_batch_size, shuffle=False)

    model = AutoModelForSequenceClassification.from_pretrained(
        CFG.model_name,
        num_labels=2,
        use_safetensors=True,
    )
    model.to(CFG.device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
    total_steps = len(train_loader) * CFG.epochs
    warmup_steps = int(total_steps * CFG.warmup_ratio)
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=warmup_steps,
        num_training_steps=total_steps,
    )

    best_state = None
    best_val_loss = float("inf")
    best_epoch = -1

    for epoch in range(1, CFG.epochs + 1):
        model.train()
        total_train_loss = 0.0
        total_train_items = 0

        for batch in train_loader:
            batch = {k: v.to(CFG.device) for k, v in batch.items()}
            optimizer.zero_grad()
            outputs = model(**batch)
            loss = outputs.loss
            if torch.isnan(loss) or torch.isinf(loss):
                continue
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), CFG.grad_clip)
            optimizer.step()
            scheduler.step()

            total_train_loss += loss.item() * batch["labels"].size(0)
            total_train_items += batch["labels"].size(0)

        avg_train_loss = total_train_loss / max(total_train_items, 1)
        val_loss, _, _, _ = evaluate(model, val_loader, threshold=CFG.threshold)

        print(f"Fold {fold_id:02d} | epoch={epoch:03d} | train_loss={avg_train_loss:.4f} | val_loss={val_loss:.4f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())

    model.load_state_dict(best_state)

    if CFG.threshold_mode == "search":
        _, _, y_val, prob_val = evaluate(model, val_loader, threshold=CFG.threshold)
        best_threshold, _ = find_best_threshold(y_val, prob_val)
    else:
        best_threshold = CFG.threshold

    _, _, y_test, prob_test = evaluate(model, test_loader, threshold=best_threshold)
    test_metrics = compute_metrics(y_test, prob_test, threshold=best_threshold)

    print(
        f"Fold {fold_id:02d} | best_epoch={best_epoch:03d} | val_loss={best_val_loss:.4f} | "
        f"thr={best_threshold:.2f} | Precision={test_metrics['pre']:.4f} | "
        f"F1={test_metrics['f1']:.4f} | AUC={test_metrics['auc']:.4f} | "
        f"Balance={test_metrics['balance']:.4f} | MCC={test_metrics['mcc']:.4f}"
    )
    return {"threshold": best_threshold, "test": test_metrics}


def summarize(metric_list):
    out = {}
    for key in ["pre", "f1", "auc", "balance", "mcc"]:
        vals = np.array([m[key] for m in metric_list], dtype=np.float64)
        out[key] = (vals.mean(), vals.std(ddof=0))
    return out


samples_all = load_jsonl_samples(CFG.data_path)
labels_all = np.array([s.label for s in samples_all], dtype=np.int32)
group_keys_all = np.array([s.group_key for s in samples_all], dtype=object)

GROUP_FOLDS, GROUP_TO_INDICES, UNIQUE_GROUPS, GROUP_LABELS = build_group_folds(group_keys_all, labels_all, CFG.n_splits, 5)
GROUP_LABEL_MAP = {str(g): int(y) for g, y in zip(UNIQUE_GROUPS, GROUP_LABELS)}

tokenizer = AutoTokenizer.from_pretrained(
    CFG.model_name,
    use_fast=True,
)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token if tokenizer.eos_token is not None else tokenizer.unk_token

all_results = []
print(f"\n🚀 Start {CFG.n_splits}-fold grouped CV with CodeBERT ...\n")
for fold_id, (idx_train_full, idx_test, train_groups, test_groups) in enumerate(GROUP_FOLDS, start=1):
    result = train_one_fold(
        fold_id,
        samples_all,
        labels_all,
        idx_train_full,
        idx_test,
        train_groups,
        test_groups,
        5 + fold_id,
        tokenizer,
    )
    all_results.append(result)

summary = summarize([r["test"] for r in all_results])
threshold_vals = np.array([r["threshold"] for r in all_results], dtype=np.float64)

print("\n" + "=" * 72)
print("🏆 CodeBERT 5-Fold CV Summary")
print("=" * 72)
print(f"Threshold   : {threshold_vals.mean():.4f} ± {threshold_vals.std(ddof=0):.4f}")
print(f"Precision   : {summary['pre'][0]:.4f} ± {summary['pre'][1]:.4f}")
print(f"F1-Score    : {summary['f1'][0]:.4f} ± {summary['f1'][1]:.4f}")
print(f"AUC         : {summary['auc'][0]:.4f} ± {summary['auc'][1]:.4f}")
print(f"Balance     : {summary['balance'][0]:.4f} ± {summary['balance'][1]:.4f}")
print(f"MCC         : {summary['mcc'][0]:.4f} ± {summary['mcc'][1]:.4f}")
print("=" * 72)
