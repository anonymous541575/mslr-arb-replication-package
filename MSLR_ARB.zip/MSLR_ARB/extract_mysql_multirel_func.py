import os
import re
import csv
import uuid
import pickle
import random
import shutil
import subprocess
import numpy as np

TARGET_AGING_FUNCTIONS = {
    '45_client_mysqlbinlog.cc': ['main', 'parse_args', 'process_event'],
    '45_sql_log_event.cc': ['Log_event::read_log_event', 'Query_log_event::print_query_header',
                            'Query_log_event::print'],
    '43_sql_sql_select.cc': ['sub_select', 'evaluate_join_record', 'end_write_group', 'copy_fields', 'do_select',
                      'JOIN::cleanup', 'JOIN::destroy', 'mysql_select', 'mysql_explain_union', 'JOIN::exec()'],
    '32_sql_sql_class.cc': ['THD::cleanup(void)'],
    '30_innobase_ha_innodb.cc': ['ha_innobase::open()', 'ha_innobase::close(void)'],
    '48_innobase_ha_innodb.cc': ['thd_to_trx(THD* thd)', 'innobase_close_connection'],
    '45_innodbplugin_log0recv.c': ['recv_scan_log_recs'],
    '37_innobase_row0mysql.c': ['row_drop_table_for_mysql'],
    '52_innobase_row0mysql.c': ['row_update_for_mysql', 'row_update_statistics_if_needed'],
    '48_sql_item_timefunc.cc': ['Item_extract::fix_length_and_dec()', 'Item_extract::val_int()'],
    '37_innobase_srv0start.c': ['innobase_start_or_create_for_mysql'],
    '37_sql_sql_table.cc': ['mysql_rm_table_part2', 'mysql_rm_table'],
    '37_innobase_ut0mem.c': ['ut_realloc', 'ut_malloc', 'ut_malloc_low'],
    '37_innobase_lexyy.c': ['yylex', 'string_append'],
    '37_innobase_srv0srv.c': ['srv_general_init', 'srv_boot'],
    '37_innobase_mem0dbg.c': ['mem_init'],
    '37_innobase_thr0loc.c': ['thr_local_init']
}

os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-21.0.10"
os.environ["PATH"] = r"C:\Program Files\Java\jdk-21.0.10\bin;" + os.environ["PATH"]
os.environ["JAVA_OPTS"] = "-Xms4G -Xmx8G"

JOERN_EXPORT_BAT = r"D:\joern-cli\joern-export.bat"
MYSQL_BIN_DIR = r"D:\mysqlbin"
ARFF_FILES = [
    r"D:\dataset_mysql_innodb.arff",
    r"D:\dataset_mysql_optimizer.arff",
    r"D:\dataset_mysql_replication.arff"
]

JOERN_NODE2ID = {
    'PAD': 0, 'METHOD': 1, 'METHOD_PARAMETER_IN': 2, 'METHOD_RETURN': 3,
    'BLOCK': 4, 'CALL': 5, 'IDENTIFIER': 6, 'RETURN': 7,
    'LOCAL': 8, 'LITERAL': 9, 'FIELD_IDENTIFIER': 10,
    'TYPE_REF': 11, 'JUMP_TARGET': 12, 'MODIFIER': 13, 'CONTROL_STRUCTURE': 14,
    'IF': 15, 'ELSE': 16, 'WHILE': 17, 'FOR': 18, 'SWITCH': 19, 'BREAK': 20, 'CONTINUE': 21,
    'MEMBER': 22, 'TYPE_DECL': 23, 'OTHER': 99
}

EDGE_TYPES = ['AST', 'CFG', 'REACHING_DEF', 'CDG', 'REF']
VALID_EDGE_LABELS = set(EDGE_TYPES)

NEG_POS_RATIO = 5
AGING_BLACKLIST = {
    'mysqlbinlog.cc', 'log_event.cc', 'sql_select.cc', 'sql_class.cc', 'log0recv.c',
    'ha_innodb.cc', 'row0mysql.c', 'item_timefunc.cc', 'srv0start.c',
    'sql_table.cc', 'ut0mem.c', 'lexyy.c', 'srv0srv.c', 'mem0dbg.c', 'thr0loc.c'
}


def get_valid_arff_filenames(arff_paths):
    valid_filenames = set()
    for path in arff_paths:
        if not os.path.exists(path):
            print(f"⚠️ warning{path}")
            continue
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            data_mode = False
            for line in f:
                line = line.strip()
                if not line or line.startswith('%'):
                    continue
                if line.lower().startswith('@data'):
                    data_mode = True
                    continue
                if data_mode:
                    parts = line.split(',')
                    if parts:
                        raw_fname = parts[0].replace("'", "").replace('"', '').strip().lower()
                        clean_fname = os.path.basename(raw_fname)
                        valid_filenames.add(clean_fname)
    return valid_filenames


def map_joern_node_to_id(node):
    label = node.get('_label', 'OTHER')
    if label == 'CONTROL_STRUCTURE':
        c_type = node.get('controlStructureType', '')
        if c_type in ['IF', 'ELSE', 'WHILE', 'FOR', 'SWITCH', 'BREAK', 'CONTINUE']:
            return JOERN_NODE2ID[c_type]
    return JOERN_NODE2ID.get(label, JOERN_NODE2ID['OTHER'])


def _normalize_method_text(s):
    s = str(s or '').strip()
    if not s:
        return ''
    return s.replace(' ', '').replace('\t', '')


def _normalize_param_text(s):
    s = _normalize_method_text(s)
    if not s:
        return ''
    if s == '()':
        return '()'
    if s.startswith('(') and s.endswith(')'):
        inner = s[1:-1]
    else:
        inner = s
    if inner == 'void':
        return '()'
    return f'({inner})'


def _parse_target_method(target_f):
    raw = _normalize_method_text(target_f)
    if '(' in raw and ')' in raw:
        before_paren = raw[:raw.find('(')]
        params = _normalize_param_text(raw[raw.find('('):])
        has_params = True
    else:
        before_paren = raw
        params = ''
        has_params = False
    return {
        'raw': raw,
        'before_paren': before_paren,
        'base_name': before_paren.split('::')[-1],
        'qualifier': '::'.join(before_paren.split('::')[:-1]) if '::' in before_paren else '',
        'has_qualifier': '::' in before_paren,
        'params': params,
        'has_params': has_params,
    }


def _extract_method_profile(method_node):
    values = {}
    for key in ['fullname', 'full_name', 'name', 'code', 'signature']:
        values[key] = _normalize_method_text(method_node.get(key, ''))

    forms = set(v for v in values.values() if v)
    name = values.get('name', '')
    fullname = values.get('fullname', '') or values.get('full_name', '')
    code = values.get('code', '')
    signature = _normalize_param_text(values.get('signature', ''))

    for val in [name, fullname, code]:
        if not val:
            continue
        base = val.split('(')[0]
        forms.add(val)
        forms.add(base)
        forms.add(base.split('::')[-1])
        if signature:
            forms.add(f"{base}{signature}")
            forms.add(f"{base.split('::')[-1]}{signature}")

    before_set, base_set, qualified_set, params_set = set(), set(), set(), set()
    for cand in forms:
        if not cand:
            continue
        if '(' in cand and ')' in cand:
            before = cand[:cand.find('(')]
            params_set.add(_normalize_param_text(cand[cand.find('('):]))
        else:
            before = cand
        before_set.add(before)
        base_set.add(before.split('::')[-1])
        if '::' in before:
            qualified_set.add(before)
    if signature:
        params_set.add(signature)

    return {
        'forms': forms,
        'before': before_set,
        'base': base_set,
        'qualified': qualified_set,
        'params': params_set,
    }


def _score_method_against_target(method_node, target_f):
    target = _parse_target_method(target_f)
    prof = _extract_method_profile(method_node)

    if target['raw'] in prof['forms']:
        return 100
    if target['before_paren'] in prof['before']:
        if (not target['has_params']) or (target['params'] in prof['params']) or (target['params'] == '()'):
            return 98
        return 94

    for cand in prof['forms']:
        if target['raw'] and target['raw'] in cand:
            return 96
        if target['before_paren'] and target['before_paren'] in cand:
            if (not target['has_params']) or (target['params'] in cand) or (target['params'] == '()'):
                return 93
            return 90

    if target['has_qualifier']:
        for q in prof['qualified']:
            if q == target['before_paren']:
                return 92
            if q.endswith(target['before_paren']):
                return 91
            if q.split('::')[-1] == target['base_name'] and target['qualifier'] in q:
                return 88
        if target['base_name'] in prof['base']:
            if target['has_params'] and target['params'] and target['params'] not in prof['params'] and target['params'] != '()':
                return -1
            return 40
        return -1

    if target['base_name'] in prof['base']:
        if target['has_params'] and target['params'] and target['params'] not in prof['params'] and target['params'] != '()':
            return 65
        return 85
    return -1


def _match_methods_to_targets(funcs, target_list):
    scored = []
    for t_idx, target_f in enumerate(target_list):
        for m_idx, m_node in enumerate(funcs):
            score = _score_method_against_target(m_node, target_f)
            if score >= 0:
                scored.append((score, t_idx, m_idx, target_f))

    scored.sort(key=lambda x: (-x[0], x[1], x[2]))
    used_targets, used_methods = set(), set()
    matched_methods = []
    for score, t_idx, m_idx, target_f in scored:
        if t_idx in used_targets or m_idx in used_methods:
            continue
        target = _parse_target_method(target_f)
        if target['has_qualifier'] and score < 80:
            continue
        if (not target['has_qualifier']) and score < 60:
            continue
        used_targets.add(t_idx)
        used_methods.add(m_idx)
        m = dict(funcs[m_idx])
        m['_matched_target'] = target_f
        m['_match_score'] = score
        matched_methods.append(m)
    return matched_methods


def is_target_aging_func(bin_name, node_filename):
    node_fname_clean = os.path.basename(node_filename).lower()
    for k, v_list in TARGET_AGING_FUNCTIONS.items():
        parts = k.split('_', 2)
        if len(parts) != 3:
            continue
        t_ver, t_comp, t_fname = parts
        if t_ver in bin_name and t_comp.lower() in bin_name.lower() and node_fname_clean.endswith(t_fname.lower()):
            return k, v_list
    return None, None


def load_joern_neo4jcsv(export_dir):
    all_nodes_dict = {}
    all_edges = []
    for root, dirs, files in os.walk(export_dir):
        for file in files:
            if not file.endswith('.csv') or file.endswith('_header.csv'):
                continue
            data_filepath = os.path.join(root, file)
            header_filepath = data_filepath.replace('_data.csv', '_header.csv')
            try:
                if os.path.exists(header_filepath):
                    with open(header_filepath, 'r', encoding='utf-8', errors='ignore') as hf:
                        headers = next(csv.reader(hf))
                else:
                    with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        headers = next(csv.reader(f))
            except StopIteration:
                continue

            is_edge = ':START_ID' in headers and ':END_ID' in headers
            is_node = ':ID' in headers or 'id' in headers

            clean_headers = []
            for h in headers:
                if h in [':START_ID', ':END_ID', ':ID', ':LABEL', ':TYPE']:
                    clean_headers.append(h)
                else:
                    clean_headers.append(h.split(':')[0].lower() if h else '')

            with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                reader = csv.reader(f)
                if not os.path.exists(header_filepath):
                    next(reader, None)
                for row in reader:
                    if not row or len(row) != len(clean_headers):
                        continue
                    row_dict = dict(zip(clean_headers, row))
                    if is_edge:
                        edge_label = row_dict.get(':TYPE') or row_dict.get('label')
                        if not edge_label:
                            edge_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        if edge_label in VALID_EDGE_LABELS:
                            all_edges.append({'out': row_dict[':START_ID'], 'in': row_dict[':END_ID'], '_label': edge_label})
                    elif is_node:
                        node_id = row_dict.get(':ID') or row_dict.get('id')
                        node_label = row_dict.get(':LABEL') or row_dict.get('label')
                        if not node_label:
                            node_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        row_dict['id'] = node_id
                        row_dict['_label'] = node_label
                        all_nodes_dict[node_id] = row_dict
    return all_nodes_dict, all_edges


def collect_method_subgraph_ids(method_node, ast_children):
    method_id = method_node['id']
    sub_node_ids = set()
    stack = [method_id]
    while stack:
        curr = stack.pop()
        if curr in sub_node_ids:
            continue
        sub_node_ids.add(curr)
        stack.extend(ast_children.get(curr, []))
    return sub_node_ids


def induce_subgraph_from_node_ids(node_ids, all_edges, edge_type=None):
    node_id_set = set(node_ids)
    if edge_type is None:
        sub_edges = [
            e for e in all_edges
            if e['_label'] in VALID_EDGE_LABELS and e['out'] in node_id_set and e['in'] in node_id_set
        ]
    else:
        sub_edges = [
            e for e in all_edges
            if e['_label'] == edge_type and e['out'] in node_id_set and e['in'] in node_id_set
        ]
    return node_id_set, sub_edges


def materialize_graph_from_ids(sampled_node_ids, sampled_edges, nodes_dict):
    if not sampled_node_ids:
        return {"nodes": [], "edges": [], "texts": []}
    sorted_ids = sorted(list(sampled_node_ids))
    id2idx = {old_id: idx for idx, old_id in enumerate(sorted_ids)}

    nodes_list, texts_list = [], []
    for old_id in sorted_ids:
        node = nodes_dict.get(old_id, {})
        node_label = node.get('_label', 'UNK')
        nodes_list.append(map_joern_node_to_id(node))
        raw_text = str(node.get('code') or node.get('name') or node_label)
        texts_list.append(raw_text)

    EDGE_L2ID = {'AST': 1, 'CFG': 2, 'REACHING_DEF': 3, 'CDG': 4, 'REF': 5}
    edges_list = []
    seen_edges = set()
    for e in sampled_edges:
        u = id2idx[e['out']]
        v = id2idx[e['in']]
        e_type = EDGE_L2ID.get(e['_label'], 1)
        tup = (u, v, e_type)
        if tup not in seen_edges:
            seen_edges.add(tup)
            edges_list.append(list(tup))
    return {"nodes": nodes_list, "edges": edges_list, "texts": texts_list}


def build_single_function_sample(method_node, file_methods, ast_children, nodes_dict, all_edges,
                                 filename, sample_kind, logic_key=None):
    func_scope_ids = collect_method_subgraph_ids(method_node, ast_children)

    sample = {
        'filename': filename,
        'logic_key': logic_key,
        'target_method_name': method_node.get('name', ''),
        'sample_kind': sample_kind,
        '_matched_target': method_node.get('_matched_target', ''),
        '_match_score': method_node.get('_match_score', -1),
    }

    local_ids, local_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=None)
    local_graph = materialize_graph_from_ids(local_ids, local_edges, nodes_dict)
    sample['func_nodes'] = local_graph['nodes']
    sample['func_edges'] = local_graph['edges']
    sample['func_texts'] = local_graph['texts']

    for et in EDGE_TYPES:
        rel_ids, rel_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=et)
        rel_graph = materialize_graph_from_ids(rel_ids, rel_edges, nodes_dict)
        prefix = f"rel_{et.lower()}"
        sample[f'{prefix}_nodes'] = rel_graph['nodes']
        sample[f'{prefix}_edges'] = rel_graph['edges']
        sample[f'{prefix}_texts'] = rel_graph['texts']

    return sample


def extract_cpg_from_export(export_dir, bin_name, valid_arff_filenames):
    nodes_dict, all_edges = load_joern_neo4jcsv(export_dir)
    method_nodes = [
        n for n in nodes_dict.values()
        if n.get('_label') == 'METHOD' and not n.get('name', '').startswith('<')
    ]
    print(f"    [radar]  {len(nodes_dict)} graph node, {len(all_edges)} Core edge connection,  {len(method_nodes)} Function Definition")

    if len(method_nodes) == 0:
        return [], []

    ast_children = {}
    for e in all_edges:
        if e['_label'] == 'AST':
            ast_children.setdefault(e['out'], []).append(e['in'])

    methods_by_file = {}
    for m_node in method_nodes:
        m_filename = m_node.get('filename', '')
        if not m_filename:
            continue
        clean_fname = os.path.basename(m_filename).lower()
        if clean_fname not in valid_arff_filenames:
            continue
        methods_by_file.setdefault(m_filename, []).append(m_node)

    aging_targets_by_logic_key = {}
    logic_key_to_filename = {}
    aging_file_set = set()
    for m_filename, funcs in methods_by_file.items():
        match_key, target_list = is_target_aging_func(bin_name, m_filename)
        if not match_key:
            continue
        matched_methods = _match_methods_to_targets(funcs, target_list)
        if matched_methods:
            aging_targets_by_logic_key[match_key] = matched_methods
            logic_key_to_filename[match_key] = m_filename
            aging_file_set.add(m_filename)
        else:
            print(f"    {os.path.basename(m_filename)} | targets={target_list}")

    extracted_aging = []
    for logic_key, target_methods in aging_targets_by_logic_key.items():
        file_name = logic_key_to_filename[logic_key]
        file_methods = methods_by_file[file_name]
        for idx, m_node in enumerate(target_methods):
            sample = build_single_function_sample(
                method_node=m_node,
                file_methods=file_methods,
                ast_children=ast_children,
                nodes_dict=nodes_dict,
                all_edges=all_edges,
                filename=file_name,
                sample_kind='aging',
                logic_key=logic_key,
            )
            sample_key = f"{logic_key}__func{idx}__{m_node.get('name', '')}"
            extracted_aging.append((sample_key, sample))

    bin_stem = os.path.splitext(os.path.basename(bin_name))[0].lower()
    if 'cpg_client_45' in bin_stem:
        print("    [Statistics] cpg_client_45: Only extract aging functions, skip non-aging files")
        return extracted_aging, []

    negative_candidate_files = []
    for m_filename in methods_by_file.keys():
        if m_filename in aging_file_set:
            continue
        clean_fname = os.path.basename(m_filename).lower()
        if clean_fname in AGING_BLACKLIST:
            continue
        negative_candidate_files.append(m_filename)

    extracted_non_aging = []
    for m_filename in negative_candidate_files:
        funcs = methods_by_file.get(m_filename, [])
        if not funcs:
            continue

        sampled_func = random.choice(funcs)
        sample = build_single_function_sample(
            method_node=sampled_func,
            file_methods=funcs,
            ast_children=ast_children,
            nodes_dict=nodes_dict,
            all_edges=all_edges,
            filename=m_filename,
            sample_kind='non_aging',
            logic_key=None,
        )
        sample['sampled_method_name'] = sampled_func.get('name', '')
        extracted_non_aging.append(sample)

    print(f"    [Statistics] aging logic keys matched = {len(aging_targets_by_logic_key)}")
    print(f"    [Statistics] aging function samples = {len(extracted_aging)}")
    print(f"    [Statistics] negative candidate files = {len(negative_candidate_files)}")
    print(f"    [Statistics] negative single-function samples = {len(extracted_non_aging)}")
    return extracted_aging, extracted_non_aging

random.seed(5)
np.random.seed(5)

def process_single_bin(bin_path, valid_arff_filenames):
    unique_id = uuid.uuid4().hex[:8]
    tmp_dir = os.path.abspath(f"tmp_mysql_multirel_export_{unique_id}")
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)
    print(f"  [Joern] Exporting {os.path.basename(bin_path)} to Neo4jCSV...")

    try:
        subprocess.run(
            ["cmd", "/c", JOERN_EXPORT_BAT, bin_path, "--repr", "all", "--format", "neo4jcsv", "--out", tmp_dir],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        graphs_aging, graphs_non_aging = extract_cpg_from_export(tmp_dir, os.path.basename(bin_path), valid_arff_filenames)
    except subprocess.CalledProcessError as e:
        print(f"  ❌ {e.returncode}")
        graphs_aging, graphs_non_aging = [], []
    except Exception as e:
        print(f"  ❌ {e}")
        graphs_aging, graphs_non_aging = [], []

    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)
    return graphs_aging, graphs_non_aging


def main():
    aging_functions_data = {}
    non_aging_pool = []

    print(f"\n🚀 Start extracting MySQL multi-relational function-level samples: local + rel_*")
    print(f"✅ Negative sample strategy: Only one function is extracted from each negative file, with the final total count = number of positive samples × {NEG_POS_RATIO}")

    valid_arff_filenames = get_valid_arff_filenames(ARFF_FILES)
    print(f"✅ Successfully extracted from ARFF {len(valid_arff_filenames)} effective static feature file name")

    for bin_dir in [MYSQL_BIN_DIR]:
        if not os.path.exists(bin_dir):
            continue
        for f in os.listdir(bin_dir):
            if not f.endswith('.bin'):
                continue
            bin_path = os.path.join(bin_dir, f)
            graphs_aging, graphs_non_aging = process_single_bin(bin_path, valid_arff_filenames)

            prefix = re.search(r'_(\d+)\.bin', f)
            prefix = prefix.group(1) if prefix else "00"

            for sample_key, g in graphs_aging:
                key = f"{prefix}_{sample_key}"
                aging_functions_data[key] = g
                print(f"  🔥 [aging function] {key} | method={g['target_method_name']} | matched={g.get('_matched_target','')} | score={g.get('_match_score',-1)} | local nodes: {len(g['func_nodes'])}")

            for idx, g in enumerate(graphs_non_aging):
                item = dict(g)
                item['prefix'] = prefix
                item['name'] = os.path.basename(g['filename'])
                item['neg_file_idx'] = idx
                non_aging_pool.append(item)

    target_neg_count = len(aging_functions_data) * NEG_POS_RATIO
    random.shuffle(non_aging_pool)
    selected_non_aging = non_aging_pool[:target_neg_count]

    non_aging_functions_data = {}
    for i, g in enumerate(selected_non_aging):
        method_name = g.get('sampled_method_name', '')
        safe_method = re.sub(r'[^A-Za-z0-9_]+', '_', method_name).strip('_') or 'unknown'
        key = f"{g['prefix']}_W_FUNCNEG_{i}_{g['name']}__{safe_method}"
        non_aging_functions_data[key] = g

    out_name = "mysql_joern_multirel_func.pkl"
    with open(out_name, 'wb') as f:
        pickle.dump({
            'aging': aging_functions_data,
            'non_aging': non_aging_functions_data,
            'relation_views': [f"rel_{e.lower()}" for e in EDGE_TYPES],
            'variant_note': f'function-level multi-relational samples; each aging function is one positive; each negative file contributes one function candidate; final negative count = positive count * {NEG_POS_RATIO}; supports local + relation fusion like NetBSD',
        }, f)

    print(f"\n🎉 saved to {out_name}")
    print(f"📌 aging samples     : {len(aging_functions_data)}")
    print(f"📌 non-aging samples : {len(non_aging_functions_data)} / target={target_neg_count}")
    if len(non_aging_functions_data) < target_neg_count:
        print("⚠️ The available negative samples are insufficient, and all extractable negative function samples have been used.")
    print(f"📌 Directly trainable relation fields:{[f'rel_{e.lower()}' for e in EDGE_TYPES]}")


if __name__ == '__main__':
    main()
