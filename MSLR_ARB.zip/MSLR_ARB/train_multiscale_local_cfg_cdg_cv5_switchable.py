import os
import copy
import math
import random
import warnings
import argparse
import pickle
import numpy as np

from dataclasses import dataclass
from typing import Dict, Tuple

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    confusion_matrix, matthews_corrcoef
)
from imblearn.over_sampling import RandomOverSampler

import torch
import torch.nn as nn
import torch.nn.functional as F

@dataclass
class Config:
    data_path: str = "netbsd_joern_multirel_func.pkl"
    local_view: str = "local"

    use_cfg: int = 1
    use_cdg: int = 1

    n_splits: int = 5
    epochs: int = 100
    lr: float = 5e-4
    weight_decay: float = 1e-4

    threshold_mode: str = "fixed"
    threshold: float = 0.5
    inner_val_ratio: float = 0.125

    local_scales: str = "30,50,100"
    local_node_embed_dim: int = 32
    local_hidden_dim: int = 64
    local_dropout: float = 0.25

    rel_node_embed_dim: int = 16
    rel_hidden_dim: int = 48
    rel_dropout: float = 0.20
    rel_max_nodes: int = 50

    fusion_dim: int = 128
    fusion_dropout: float = 0.3

    use_focal_loss: bool = True
    focal_alpha: float = 0.75
    focal_gamma: float = 2.0

    usemodel: str = "GCN"  # GCN / GAT / GraphSAGE
    gat_heads: int = 4

    grad_clip: float = 2.0
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


CFG = Config()

parser = argparse.ArgumentParser()
parser.add_argument("--data_path", type=str, default=CFG.data_path)
parser.add_argument("--local_view", type=str, default=CFG.local_view)
parser.add_argument("--use_cfg", type=int, default=CFG.use_cfg)
parser.add_argument("--use_cdg", type=int, default=CFG.use_cdg)

parser.add_argument("--n_splits", type=int, default=CFG.n_splits)
parser.add_argument("--epochs", type=int, default=CFG.epochs)
parser.add_argument("--lr", type=float, default=CFG.lr)
parser.add_argument("--weight_decay", type=float, default=CFG.weight_decay)

parser.add_argument("--threshold_mode", type=str, default=CFG.threshold_mode, choices=["fixed", "search"])
parser.add_argument("--threshold", type=float, default=CFG.threshold)
parser.add_argument("--inner_val_ratio", type=float, default=CFG.inner_val_ratio)

parser.add_argument("--local_scales", type=str, default=CFG.local_scales)
parser.add_argument("--rel_max_nodes", type=int, default=CFG.rel_max_nodes)

parser.add_argument("--use_focal_loss", type=int, default=1)
parser.add_argument("--focal_alpha", type=float, default=CFG.focal_alpha)
parser.add_argument("--focal_gamma", type=float, default=CFG.focal_gamma)

parser.add_argument("--usemodel", type=str, default=CFG.usemodel, choices=["GCN", "GAT", "GraphSAGE", "SAGE", "sage", "gcn", "gat"])
parser.add_argument("--gat_heads", type=int, default=CFG.gat_heads)
args = parser.parse_args()

CFG.data_path = args.data_path
CFG.local_view = args.local_view
CFG.use_cfg = int(args.use_cfg)
CFG.use_cdg = int(args.use_cdg)
CFG.n_splits = args.n_splits
CFG.epochs = args.epochs
CFG.lr = args.lr
CFG.weight_decay = args.weight_decay
CFG.threshold_mode = args.threshold_mode
CFG.threshold = args.threshold
CFG.inner_val_ratio = args.inner_val_ratio
CFG.local_scales = args.local_scales
CFG.rel_max_nodes = args.rel_max_nodes
CFG.use_focal_loss = bool(args.use_focal_loss)
CFG.focal_alpha = args.focal_alpha
CFG.focal_gamma = args.focal_gamma
CFG.usemodel = str(args.usemodel).strip().upper()
if CFG.usemodel == "SAGE":
    CFG.usemodel = "GRAPHSAGE"
CFG.gat_heads = max(1, int(args.gat_heads))

LOCAL_SCALES = [int(x.strip()) for x in CFG.local_scales.split(",") if x.strip()]
ACTIVE_REL_VIEWS = []
if CFG.use_cfg:
    ACTIVE_REL_VIEWS.append("rel_cfg")
if CFG.use_cdg:
    ACTIVE_REL_VIEWS.append("rel_cdg")

print(f"Using device: {CFG.device}")
print(f"data_path        = {CFG.data_path}")
print(f"local_view       = {CFG.local_view}")
print(f"local_scales     = {LOCAL_SCALES}")
print(f"active_rel_views = {ACTIVE_REL_VIEWS}")
print(f"n_splits         = {CFG.n_splits}")
print(f"threshold_mode   = {CFG.threshold_mode}")
print(f"threshold        = {CFG.threshold}")
print(f"usemodel         = {CFG.usemodel}")
print(f"gat_heads        = {CFG.gat_heads}")

with open(CFG.data_path, "rb") as f:
    dataset = pickle.load(f)

aging_data = dataset["aging"]
non_aging_data = dataset["non_aging"]
print(f"🌟  PKL：aging={len(aging_data)}, non_aging={len(non_aging_data)}")


def normalize_filename_for_group(name: str) -> str:
    return os.path.basename(str(name)).replace('\\', '/').split('/')[-1].strip().lower()


def extract_prefix_from_sample_key(sample_key: str) -> str:
    sample_key = str(sample_key)
    return sample_key.split('_', 1)[0] if '_' in sample_key else 'NA'


def build_group_key(sample_key: str, filename: str) -> str:
    prefix = extract_prefix_from_sample_key(sample_key)
    fname = normalize_filename_for_group(filename)
    return f"{prefix}::{fname}"


def resolve_view_fields(g: Dict, view_name: str) -> Tuple[str, str, str]:
    if view_name == "local":
        if all(k in g for k in ["func_nodes", "func_edges", "func_texts"]):
            return "func_nodes", "func_edges", "func_texts"
        raise KeyError("local ： func_*")
    node_field = f"{view_name}_nodes"
    edge_field = f"{view_name}_edges"
    text_field = f"{view_name}_texts"
    if all(k in g for k in [node_field, edge_field, text_field]):
        return node_field, edge_field, text_field
    raise KeyError(f" {view_name} ")


class GraphSample:
    def __init__(self, node_ids, edge_index, label, sample_key, filename):
        self.node_ids = node_ids
        self.edge_index = edge_index
        self.label = label
        self.sample_key = sample_key
        self.filename = filename


def build_graph_sample(nodes, edges, label, sample_key, filename):
    nodes = np.asarray(nodes, dtype=np.int64)
    edges = np.asarray(edges, dtype=np.int64)
    if len(nodes) == 0:
        node_ids = torch.zeros((1,), dtype=torch.long)
        edge_index = torch.zeros((2, 0), dtype=torch.long)
    else:
        node_ids = torch.tensor(nodes, dtype=torch.long)
        if edges.ndim == 2 and edges.shape[0] > 0:
            edge_index = torch.tensor(edges[:, :2].T, dtype=torch.long)
        else:
            edge_index = torch.zeros((2, 0), dtype=torch.long)
    return GraphSample(node_ids, edge_index, torch.tensor(float(label), dtype=torch.float32), str(sample_key), str(filename))


class MultiRelSample:
    def __init__(self, sample_key, filename, label, local_graph, rel_graphs):
        self.sample_key = sample_key
        self.filename = filename
        self.label = label
        self.local_graph = local_graph
        self.rel_graphs = rel_graphs


def build_samples():
    samples, labels, group_keys = [], [], []

    def consume(data_dict, label):
        for key, g in data_dict.items():
            local_nf, local_ef, _ = resolve_view_fields(g, CFG.local_view)
            local_graph = build_graph_sample(g[local_nf], g[local_ef], label, key, g.get("filename", ""))
            rel_graphs = {}
            for rv in ACTIVE_REL_VIEWS:
                nf, ef, _ = resolve_view_fields(g, rv)
                rel_graphs[rv] = build_graph_sample(g[nf], g[ef], label, key, g.get("filename", ""))
            samples.append(MultiRelSample(str(key), str(g.get("filename", "")), torch.tensor(float(label), dtype=torch.float32), local_graph, rel_graphs))
            labels.append(label)
            group_keys.append(build_group_key(key, g.get("filename", "")))

    consume(aging_data, 1)
    consume(non_aging_data, 0)
    return samples, np.array(labels, dtype=np.int32), np.array(group_keys, dtype=object)


all_samples, labels_all, group_keys_all = build_samples()

VOCAB_SIZE = 0
for s in all_samples:
    for g in [s.local_graph] + [s.rel_graphs[k] for k in ACTIVE_REL_VIEWS]:
        if g.node_ids.numel() > 0:
            VOCAB_SIZE = max(VOCAB_SIZE, int(g.node_ids.max().item()))
VOCAB_SIZE += 1
print(f"✅ Built samples: {len(all_samples)} | vocab={VOCAB_SIZE}")


def build_dense_adj(num_nodes: int, edge_index: torch.Tensor, device: str):
    A = torch.zeros((num_nodes, num_nodes), dtype=torch.float32, device=device)
    if edge_index.numel() > 0:
        src = edge_index[0].to(device)
        dst = edge_index[1].to(device)
        valid_mask = (src >= 0) & (src < num_nodes) & (dst >= 0) & (dst < num_nodes)
        src = src[valid_mask]
        dst = dst[valid_mask]
        A[src, dst] = 1.0
        A[dst, src] = 1.0
    A = A + torch.eye(num_nodes, device=device)
    return A


def build_mean_adj(num_nodes: int, edge_index: torch.Tensor, device: str):
    """Mean adjacency with self-loops; kept for compatibility if needed elsewhere."""
    A = build_dense_adj(num_nodes, edge_index, device)
    deg = A.sum(dim=-1, keepdim=True).clamp(min=1.0)
    return A / deg


def build_neighbor_mean_adj_without_self(num_nodes: int, edge_index: torch.Tensor, device: str):
    """Neighbor-only mean adjacency for standard GraphSAGE mean aggregation.

    This matrix does NOT add self-loops. Therefore, A @ x aggregates only neighbors,
    while the self representation is handled by a separate self branch.
    """
    A = torch.zeros((num_nodes, num_nodes), dtype=torch.float32, device=device)
    if edge_index.numel() > 0:
        src = edge_index[0].to(device)
        dst = edge_index[1].to(device)
        valid_mask = (src >= 0) & (src < num_nodes) & (dst >= 0) & (dst < num_nodes)
        src = src[valid_mask]
        dst = dst[valid_mask]
        A[src, dst] = 1.0
        A[dst, src] = 1.0
    deg = A.sum(dim=-1, keepdim=True)
    deg_safe = deg.clamp(min=1.0)
    A_mean = A / deg_safe
    # For isolated nodes, neighbor aggregation should contribute zero rather than self.
    A_mean = torch.where(deg > 0, A_mean, torch.zeros_like(A_mean))
    return A_mean


def build_gcn_adj(num_nodes: int, edge_index: torch.Tensor, device: str):
    A = build_dense_adj(num_nodes, edge_index, device)
    deg = A.sum(dim=-1).clamp(min=1.0)
    deg_inv_sqrt = deg.pow(-0.5)
    D = torch.diag(deg_inv_sqrt)
    return D @ A @ D


def truncate_graph_by_degree(graph: GraphSample, max_nodes: int) -> GraphSample:
    if max_nodes <= 0:
        return graph
    num_nodes = int(graph.node_ids.numel())
    if num_nodes <= max_nodes:
        return graph
    edge_index = graph.edge_index
    node_ids = graph.node_ids
    deg = torch.zeros(num_nodes, dtype=torch.long)
    if edge_index.numel() > 0:
        src = edge_index[0]
        dst = edge_index[1]
        valid_mask = (src >= 0) & (src < num_nodes) & (dst >= 0) & (dst < num_nodes)
        src = src[valid_mask]
        dst = dst[valid_mask]
        deg.index_add_(0, src, torch.ones_like(src))
        deg.index_add_(0, dst, torch.ones_like(dst))
    scores = deg.numpy()
    order = np.lexsort((np.arange(num_nodes), -scores))
    keep_nodes = np.sort(order[:max_nodes])
    keep_nodes_t = torch.tensor(keep_nodes, dtype=torch.long)
    remap = -torch.ones(num_nodes, dtype=torch.long)
    remap[keep_nodes_t] = torch.arange(len(keep_nodes_t), dtype=torch.long)
    if edge_index.numel() > 0:
        src = edge_index[0]
        dst = edge_index[1]
        src_valid = (src >= 0) & (src < num_nodes)
        dst_valid = (dst >= 0) & (dst < num_nodes)
        valid = src_valid & dst_valid
        src = src[valid]
        dst = dst[valid]
        keep_mask = (remap[src] >= 0) & (remap[dst] >= 0)
        new_src = remap[src[keep_mask]]
        new_dst = remap[dst[keep_mask]]
        new_edge_index = torch.stack([new_src, new_dst], dim=0) if new_src.numel() > 0 else torch.zeros((2, 0), dtype=torch.long)
    else:
        new_edge_index = torch.zeros((2, 0), dtype=torch.long)
    return GraphSample(node_ids[keep_nodes_t], new_edge_index, graph.label.clone(), graph.sample_key, graph.filename)


def compute_balance(y_true, y_pred):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    pf = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    return 1 - (math.sqrt((0 - pf) ** 2 + (1 - rec) ** 2) / math.sqrt(2))


def compute_metrics(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.5
    balance = compute_balance(y_true, y_pred)
    try:
        mcc = matthews_corrcoef(y_true, y_pred)
    except Exception:
        mcc = 0.0
    return {"pre": float(precision), "rec": float(recall), "f1": float(f1), "auc": float(auc), "balance": float(balance), "mcc": float(mcc)}


class BinaryFocalLoss(nn.Module):
    def __init__(self, alpha=0.75, gamma=2.0, reduction="mean"):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, logits, targets):
        logits = logits.view(-1)
        targets = targets.view(-1).float()
        bce_loss = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
        probs = torch.sigmoid(logits)
        pt = torch.where(targets == 1, probs, 1 - probs)
        alpha_t = torch.where(targets == 1, torch.full_like(targets, self.alpha), torch.full_like(targets, 1.0 - self.alpha))
        focal_loss = alpha_t * ((1.0 - pt).clamp(min=1e-8) ** self.gamma) * bce_loss
        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        return focal_loss


def build_criterion():
    if CFG.use_focal_loss:
        return BinaryFocalLoss(alpha=CFG.focal_alpha, gamma=CFG.focal_gamma, reduction="mean")
    return nn.BCEWithLogitsLoss()


class AttentionPooling(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        hidden = max(in_dim // 2, 1)
        self.gate = nn.Sequential(nn.Linear(in_dim, hidden), nn.Tanh(), nn.Linear(hidden, 1))

    def forward(self, x):
        w = torch.softmax(self.gate(x), dim=0)
        return (w * x).sum(dim=0)


class GCNLayer(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        self.lin = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x, edge_index):
        A_hat = build_gcn_adj(x.size(0), edge_index, x.device)
        h = self.lin(A_hat @ x)
        h = F.relu(h)
        h = self.drop(h)
        h = self.norm(h)
        return h


class GraphSAGELayer(nn.Module):
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        self.lin_self = nn.Linear(dim, dim)
        self.lin_neigh = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x, edge_index):
        # Standard GraphSAGE mean aggregation: neighbor mean excludes self,
        # and self information is modeled by a separate self branch.
        A_neigh = build_neighbor_mean_adj_without_self(x.size(0), edge_index, x.device)
        neigh = A_neigh @ x
        h = self.lin_self(x) + self.lin_neigh(neigh)
        h = F.relu(h)
        h = self.drop(h)
        h = self.norm(h)
        return h


class GATLayer(nn.Module):
    def __init__(self, dim, heads=4, dropout=0.2):
        super().__init__()
        self.dim = dim
        self.heads = max(1, heads)
        assert dim % self.heads == 0, f"hidden dim {dim}  heads {self.heads} "
        self.head_dim = dim // self.heads
        self.lin = nn.Linear(dim, dim, bias=False)
        self.att_src = nn.Parameter(torch.empty(self.heads, self.head_dim))
        self.att_dst = nn.Parameter(torch.empty(self.heads, self.head_dim))
        self.bias = nn.Parameter(torch.zeros(dim))
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)
        self.leaky_relu = nn.LeakyReLU(0.2)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.lin.weight)
        nn.init.xavier_uniform_(self.att_src)
        nn.init.xavier_uniform_(self.att_dst)
        nn.init.zeros_(self.bias)

    def forward(self, x, edge_index):
        n = x.size(0)
        device = x.device
        A = build_dense_adj(n, edge_index, device)
        Wh = self.lin(x).view(n, self.heads, self.head_dim)
        alpha_src = (Wh * self.att_src.unsqueeze(0)).sum(dim=-1)  # [n, h]
        alpha_dst = (Wh * self.att_dst.unsqueeze(0)).sum(dim=-1)  # [n, h]

        e = self.leaky_relu(alpha_src.unsqueeze(1) + alpha_dst.unsqueeze(0))  # [n, n, h]
        mask = (A > 0).unsqueeze(-1)
        minus_inf = torch.full_like(e, -1e9)
        e_masked = torch.where(mask, e, minus_inf)
        att = torch.softmax(e_masked, dim=1)
        att = self.drop(att)

        out = torch.einsum('ijh,jhd->ihd', att, Wh).reshape(n, self.dim) + self.bias
        h = F.elu(out)
        h = self.drop(h)
        h = self.norm(h)
        return h


class GraphEncoder(nn.Module):
    def __init__(self, vocab_size: int, node_embed_dim: int, hidden_dim: int, dropout: float, model_type: str):
        super().__init__()
        self.model_type = model_type
        self.node_emb = nn.Embedding(vocab_size, node_embed_dim)
        self.input_proj = nn.Linear(node_embed_dim, hidden_dim)

        if model_type == "GCN":
            block_cls = lambda: GCNLayer(hidden_dim, dropout)
        elif model_type == "GAT":
            block_cls = lambda: GATLayer(hidden_dim, heads=CFG.gat_heads, dropout=dropout)
        elif model_type == "GRAPHSAGE":
            block_cls = lambda: GraphSAGELayer(hidden_dim, dropout)
        else:
            raise ValueError(f"Unsupported model_type: {model_type}")

        self.block1 = block_cls()
        self.block2 = block_cls()
        self.block3 = block_cls()
        self.att_pool = AttentionPooling(hidden_dim * 3)
        self.out_dim = hidden_dim * 3 * 2

    def forward(self, graph: GraphSample):
        node_ids = graph.node_ids.to(CFG.device)
        edge_index = graph.edge_index.to(CFG.device)
        x = F.relu(self.input_proj(self.node_emb(node_ids)))
        x = torch.nan_to_num(x, nan=0.0, posinf=1e4, neginf=-1e4)
        h1 = self.block1(x, edge_index)
        h2 = self.block2(h1, edge_index)
        h3 = self.block3(h2, edge_index)
        h = torch.cat([h1, h2, h3], dim=-1)
        return torch.cat([self.att_pool(h), h.max(dim=0).values], dim=-1)


class MultiScaleLocalAggregator(nn.Module):
    def __init__(self, local_dim: int, proj_dim: int):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(local_dim, proj_dim),
            nn.ReLU(),
            nn.Dropout(CFG.fusion_dropout)
        )
        self.att = nn.Sequential(
            nn.Linear(proj_dim, 64),
            nn.Tanh(),
            nn.Linear(64, 1)
        )
        self.out_dim = proj_dim * 2

    def forward(self, scale_vecs):
        X = torch.stack([self.proj(v) for v in scale_vecs], dim=0)
        alpha = torch.softmax(self.att(X), dim=0)
        att_vec = (alpha * X).sum(dim=0)
        max_vec = X.max(dim=0).values
        return torch.cat([att_vec, max_vec], dim=-1)


class MultiScaleLocalCfgCdgResidualModel(nn.Module):
    def __init__(self, vocab_size: int):
        super().__init__()
        self.local_encoder = GraphEncoder(vocab_size, CFG.local_node_embed_dim, CFG.local_hidden_dim, CFG.local_dropout, CFG.usemodel)
        self.rel_encoder = GraphEncoder(vocab_size, CFG.rel_node_embed_dim, CFG.rel_hidden_dim, CFG.rel_dropout, CFG.usemodel)

        self.local_aggr = MultiScaleLocalAggregator(self.local_encoder.out_dim, CFG.fusion_dim)

        self.rel_proj = nn.Sequential(
            nn.Linear(self.rel_encoder.out_dim, CFG.fusion_dim),
            nn.ReLU(),
            nn.Dropout(CFG.fusion_dropout)
        )

        self.rel_gates = nn.ModuleDict({
            rv: nn.Sequential(
                nn.Linear(CFG.fusion_dim * 3, 64),
                nn.ReLU(),
                nn.Linear(64, 1)
            ) for rv in ACTIVE_REL_VIEWS
        })

        self.backbone_proj = nn.Sequential(
            nn.Linear(self.local_aggr.out_dim, CFG.fusion_dim),
            nn.ReLU(),
            nn.Dropout(CFG.fusion_dropout)
        )

        fusion_in_dim = CFG.fusion_dim * 3
        self.cls = nn.Sequential(
            nn.Linear(fusion_in_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.35),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1)
        )

    def forward(self, sample: MultiRelSample):
        local_scale_vecs = []
        for scale in LOCAL_SCALES:
            g = truncate_graph_by_degree(sample.local_graph, scale)
            local_scale_vecs.append(self.local_encoder(g))
        h_local_ms = self.local_aggr(local_scale_vecs)
        h_backbone = self.backbone_proj(h_local_ms)

        residual = torch.zeros_like(h_backbone)
        for rv in ACTIVE_REL_VIEWS:
            rel_graph = truncate_graph_by_degree(sample.rel_graphs[rv], CFG.rel_max_nodes)
            h_rel = self.rel_proj(self.rel_encoder(rel_graph))
            gate_in = torch.cat([h_backbone, h_rel, torch.abs(h_backbone - h_rel)], dim=-1)
            alpha = torch.sigmoid(self.rel_gates[rv](gate_in)).squeeze(-1)
            residual = residual + alpha * h_rel

        h_fused = h_backbone + residual
        h_abs = torch.abs(h_backbone - h_fused)
        z = torch.cat([h_backbone, h_fused, h_abs], dim=-1)
        z = torch.nan_to_num(z, nan=0.0, posinf=1e4, neginf=-1e4)
        out = self.cls(z).squeeze(-1)
        return torch.nan_to_num(out, nan=0.0, posinf=20.0, neginf=-20.0)


def make_ros_indices(idx_train, y_all, seed):
    y_train = y_all[idx_train]
    local_idx = np.arange(len(idx_train)).reshape(-1, 1)
    ros = RandomOverSampler(random_state=seed)
    local_idx_ros, _ = ros.fit_resample(local_idx, y_train)
    return idx_train[local_idx_ros.flatten()]


def build_group_level_arrays(group_keys, y_all):
    group_to_indices = {}
    for idx, gk in enumerate(group_keys):
        group_to_indices.setdefault(str(gk), []).append(idx)
    unique_groups = np.array(sorted(group_to_indices.keys()), dtype=object)
    group_labels = []
    for gk in unique_groups:
        idxs = group_to_indices[gk]
        labels = y_all[idxs]
        if not np.all(labels == labels[0]):
            raise ValueError(f" {gk} ")
        group_labels.append(int(labels[0]))
    return group_to_indices, unique_groups, np.array(group_labels, dtype=np.int32)


def groups_to_sample_indices(groups, group_to_indices):
    out = []
    for gk in groups:
        out.extend(group_to_indices[str(gk)])
    return np.array(sorted(out), dtype=np.int32)


def build_group_folds(group_keys, y_all, n_splits, seed):
    group_to_indices, unique_groups, group_labels = build_group_level_arrays(group_keys, y_all)
    pos_groups = int((group_labels == 1).sum())
    neg_groups = int((group_labels == 0).sum())
    max_valid_splits = min(n_splits, pos_groups, neg_groups)
    skf = StratifiedKFold(n_splits=max_valid_splits, shuffle=True, random_state=seed)
    folds = []
    for train_group_idx, test_group_idx in skf.split(unique_groups, group_labels):
        train_groups = unique_groups[train_group_idx]
        test_groups = unique_groups[test_group_idx]
        idx_train = groups_to_sample_indices(train_groups, group_to_indices)
        idx_test = groups_to_sample_indices(test_groups, group_to_indices)
        folds.append((idx_train, idx_test, train_groups, test_groups))
    return folds, group_to_indices, unique_groups, group_labels


def split_train_val_from_outer_train_grouped(train_groups, group_to_indices, group_labels_map, seed):
    train_groups = np.array(list(train_groups), dtype=object)
    y_groups = np.array([group_labels_map[str(g)] for g in train_groups], dtype=np.int32)
    desired_val_groups = max(1, int(round(len(train_groups) * CFG.inner_val_ratio)))
    max_valid = min((y_groups == 1).sum(), (y_groups == 0).sum())
    if max_valid >= 2 and len(train_groups) >= 4 and desired_val_groups >= 1:
        n_splits_inner = min(max(2, int(round(1.0 / max(CFG.inner_val_ratio, 1e-6)))), max_valid, len(train_groups))
        skf_inner = StratifiedKFold(n_splits=n_splits_inner, shuffle=True, random_state=seed)
        inner_train_idx, inner_val_idx = next(skf_inner.split(train_groups, y_groups))
        return groups_to_sample_indices(train_groups[inner_train_idx], group_to_indices), groups_to_sample_indices(train_groups[inner_val_idx], group_to_indices)

    pos_groups = train_groups[y_groups == 1].tolist()
    neg_groups = train_groups[y_groups == 0].tolist()
    rnd = random.Random(seed)
    rnd.shuffle(pos_groups)
    rnd.shuffle(neg_groups)
    n_pos_val = max(1, int(round(len(pos_groups) * CFG.inner_val_ratio))) if len(pos_groups) >= 2 else 0
    n_neg_val = max(1, int(round(len(neg_groups) * CFG.inner_val_ratio))) if len(neg_groups) >= 2 else 0
    val_groups = pos_groups[:n_pos_val] + neg_groups[:n_neg_val]
    train_split_groups = pos_groups[n_pos_val:] + neg_groups[n_neg_val:]
    return groups_to_sample_indices(train_split_groups, group_to_indices), groups_to_sample_indices(val_groups, group_to_indices)


GROUP_FOLDS, GROUP_TO_INDICES, UNIQUE_GROUPS, GROUP_LABELS = build_group_folds(group_keys_all, labels_all, CFG.n_splits, 5)
GROUP_LABEL_MAP = {str(g): int(y) for g, y in zip(UNIQUE_GROUPS, GROUP_LABELS)}

def evaluate(model, indices, threshold=0.5):
    model.eval()
    criterion = build_criterion()
    all_probs, all_true = [], []
    total_loss = 0.0
    with torch.no_grad():
        for idx in indices:
            sample = all_samples[idx]
            y = sample.label.to(CFG.device).view(1)
            logits = model(sample).view(1)
            loss = criterion(logits, y)
            total_loss += loss.item()
            all_probs.append(torch.sigmoid(logits).item())
            all_true.append(float(sample.label.item()))
    y_prob = np.array(all_probs, dtype=np.float32)
    y_true = np.array(all_true, dtype=np.float32)
    return total_loss / max(len(indices), 1), compute_metrics(y_true, y_prob, threshold), y_true, y_prob


def find_best_threshold(y_true, y_prob):
    best_threshold, best_metrics, best_key = 0.5, None, (-1.0, -1.0, -1.0)
    for threshold in np.arange(0.001, 0.999, 0.05):
        metrics = compute_metrics(y_true, y_prob, threshold=float(threshold))
        key = (metrics["f1"], metrics["mcc"], metrics["auc"])
        if key > best_key:
            best_key, best_threshold, best_metrics = key, float(threshold), metrics
    return best_threshold, best_metrics

os.environ["PYTHONHASHSEED"] = str(5)
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
random.seed(5)
np.random.seed(5)
torch.manual_seed(5)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(5)
try:
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
except Exception:
    pass
warnings.filterwarnings("ignore")


def reset_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def train_one_fold(fold_id: int, idx_train_full, idx_test, train_groups, test_groups, seed: int):
    reset_seed(seed)
    idx_train_inner, idx_val_inner = split_train_val_from_outer_train_grouped(train_groups, GROUP_TO_INDICES, GROUP_LABEL_MAP, seed)
    idx_train_ros = make_ros_indices(idx_train_inner, labels_all, seed)

    print(
        f"Fold {fold_id:02d} split | "
        f"train groups={len(train_groups)}, val groups={len(set(group_keys_all[idx_val_inner]))}, test groups={len(test_groups)} | "
        f"train pos/neg={int(labels_all[idx_train_inner].sum())}/{int(len(idx_train_inner)-labels_all[idx_train_inner].sum())}, "
        f"val pos/neg={int(labels_all[idx_val_inner].sum())}/{int(len(idx_val_inner)-labels_all[idx_val_inner].sum())}, "
        f"test pos/neg={int(labels_all[idx_test].sum())}/{int(len(idx_test)-labels_all[idx_test].sum())}"
    )

    model = MultiScaleLocalCfgCdgResidualModel(vocab_size=VOCAB_SIZE).to(CFG.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
    criterion = build_criterion()

    best_state, best_val_loss, best_epoch = None, float("inf"), -1
    for epoch in range(1, CFG.epochs + 1):
        model.train()
        shuffled = np.random.permutation(idx_train_ros)
        for idx in shuffled:
            sample = all_samples[int(idx)]
            y = sample.label.to(CFG.device).view(1)
            optimizer.zero_grad()
            logits = model(sample).view(1)
            loss = criterion(logits, y)
            if torch.isnan(loss) or torch.isinf(loss):
                continue
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), CFG.grad_clip)
            optimizer.step()

        val_loss, _, _, _ = evaluate(model, idx_val_inner, threshold=CFG.threshold)
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())

    model.load_state_dict(best_state)

    if CFG.threshold_mode == "search":
        _, _, y_val, prob_val = evaluate(model, idx_val_inner, threshold=CFG.threshold)
        best_threshold, _ = find_best_threshold(y_val, prob_val)
    else:
        best_threshold = CFG.threshold

    _, _, y_test, prob_test = evaluate(model, idx_test, threshold=CFG.threshold)
    test_metrics = compute_metrics(y_test, prob_test, threshold=best_threshold)

    print(
        f"Fold {fold_id:02d} | best_epoch={best_epoch:03d} | val_loss={best_val_loss:.4f} | "
        f"thr={best_threshold:.2f} | Precision={test_metrics['pre']:.4f} | "
        f"F1={test_metrics['f1']:.4f} | AUC={test_metrics['auc']:.4f} | "
        f"Balance={test_metrics['balance']:.4f} | MCC={test_metrics['mcc']:.4f}"
    )
    return {"threshold": best_threshold, "test": test_metrics}


all_results = []
print(f"\n🚀 Start {CFG.n_splits}-fold CV with multi-scale local + CFG/CDG residual fusion | encoder={CFG.usemodel} ...\n")
for fold_id, (idx_train_full, idx_test, train_groups, test_groups) in enumerate(GROUP_FOLDS, start=1):
    all_results.append(train_one_fold(fold_id, idx_train_full, idx_test, train_groups, test_groups, 5 + fold_id))


def summarize(metric_list):
    out = {}
    for key in ["pre", "f1", "auc", "balance", "mcc"]:
        vals = np.array([m[key] for m in metric_list], dtype=np.float64)
        out[key] = (vals.mean(), vals.std(ddof=0))
    return out


summary = summarize([r["test"] for r in all_results])
threshold_vals = np.array([r["threshold"] for r in all_results], dtype=np.float64)

print("\n" + "=" * 72)
print(f"🏆 {CFG.usemodel} | Multi-Scale Local + CFG/CDG Residual 5-Fold CV Summary")
print("=" * 72)
print(f"LocalScales : {LOCAL_SCALES}")
print(f"ActiveRels  : {ACTIVE_REL_VIEWS}")
print(f"Threshold   : {threshold_vals.mean():.4f} ± {threshold_vals.std(ddof=0):.4f}")
print(f"Precision   : {summary['pre'][0]:.4f} ± {summary['pre'][1]:.4f}")
print(f"F1-Score    : {summary['f1'][0]:.4f} ± {summary['f1'][1]:.4f}")
print(f"AUC         : {summary['auc'][0]:.4f} ± {summary['auc'][1]:.4f}")
print(f"Balance     : {summary['balance'][0]:.4f} ± {summary['balance'][1]:.4f}")
print(f"MCC         : {summary['mcc'][0]:.4f} ± {summary['mcc'][1]:.4f}")
print("=" * 72)
