import os
import csv
import uuid
import pickle
import random
import shutil
import subprocess
import numpy as np
from collections import defaultdict

TARGET_AGING_FUNCTIONS = {
    'kern/kern_exec.c': ['execve_runproc'],
    'kern/kern_exit.c': ['proc_reparent'],
    'kern/kern_synch.c': ['suspendsched'],
    'fs/tmpfs/tmpfs_subr.c': ['tmpfs_construct_node'],
    'usr.bin/msgs/msgs.c': ['ask'],
    'usr.sbin/isdn/isdnd/exec.c': ['upd_callstat_file'],
    'usr.bin/error/filter.c': ['getignored'],
    'usr.sbin/lpr/pac/pac.c': ['dumpit'],
    'usr.bin/showmount/showmount.c': ['xdr_exports'],
    'usr.sbin/sysinst/disks.c': ['make_filesystems', 'fsck_preen'],
    'usr.sbin/sysinst/savenewlabel.c': ['savenewlabel'],
    'kern/kern_event.c': ['kqueue_scan', 'knote_detach'],
    'usr.bin/elf2aout/elf2aout.c': ['saveRead'],
    'crypto/dist/ipsec-tools/src/racoon/isakmp_xauth.c': ['xauth_rmconf_dup'],
    'usr.bin/infocmp/infocmp.c': ['use_terms'],
    'usr.sbin/sup/source/scan.c': ['parserelease'],
    'usr.sbin/sup/source/cvt.c': ['main'],
    'usr.sbin/makemandb/makemandb.c': ['read_and_decompress']
}

os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-21.0.10"
os.environ["PATH"] = r"C:\Program Files\Java\jdk-21.0.10\bin;" + os.environ["PATH"]
os.environ["JAVA_OPTS"] = "-Xms4G -Xmx8G"

JOERN_EXPORT_BAT = r"D:\joern-cli\joern-export.bat"
NETBSD_BIN_DIR = r"D:\netbsdbin"
NETBSD_CSV = r"D:\netbsd.csv"

JOERN_NODE2ID = {
    'PAD': 0, 'METHOD': 1, 'METHOD_PARAMETER_IN': 2, 'METHOD_RETURN': 3,
    'BLOCK': 4, 'CALL': 5, 'IDENTIFIER': 6, 'RETURN': 7,
    'LOCAL': 8, 'LITERAL': 9, 'FIELD_IDENTIFIER': 10,
    'TYPE_REF': 11, 'JUMP_TARGET': 12, 'MODIFIER': 13, 'CONTROL_STRUCTURE': 14,
    'IF': 15, 'ELSE': 16, 'WHILE': 17, 'FOR': 18, 'SWITCH': 19, 'BREAK': 20, 'CONTINUE': 21,
    'MEMBER': 22, 'TYPE_DECL': 23, 'OTHER': 99
}

EDGE_TYPES = ['AST', 'CFG', 'REACHING_DEF', 'CDG', 'REF']
VALID_EDGE_LABELS = set(EDGE_TYPES)

COMPONENT_PREFIX_MAP = {
    "cpg_netbsd_dist.bin": "crypto/dist/",
    "cpg_netbsd_fs.bin": "fs/",
    "cpg_netbsd_kern.bin": "kern/",
    "cpg_netbsd_usrbin.bin": "usr.bin/",
    "cpg_netbsd_usrsbin.bin": "usr.sbin/",
}


def normalize_path(s):
    return str(s).replace("\\", "/").strip()


def normalize_basename(s):
    return os.path.basename(normalize_path(s)).lower()


def get_valid_csv_filenames(csv_path):
    valid = set()
    with open(csv_path, 'r', encoding='utf-8', errors='ignore', newline='') as f:
        reader = csv.DictReader(f)
        if "Filename" not in reader.fieldnames:
            raise ValueError("CSV lack Filename ")
        for row in reader:
            fn = normalize_path(row["Filename"])
            if fn:
                valid.add(fn)
    return valid


def get_component_prefix_from_bin(bin_name):
    bn = os.path.basename(bin_name).lower()
    for k, v in COMPONENT_PREFIX_MAP.items():
        if bn == k.lower():
            return v
    if "dist" in bn:
        return "crypto/dist/"
    if "_fs" in bn or "fs.bin" in bn:
        return "fs/"
    if "_kern" in bn or "kern.bin" in bn:
        return "kern/"
    if "usrbin" in bn and "usrsbin" not in bn:
        return "usr.bin/"
    if "usrsbin" in bn:
        return "usr.sbin/"
    return None


def map_joern_node_to_id(node):
    label = node.get('_label', 'OTHER')
    if label == 'CONTROL_STRUCTURE':
        c_type = str(node.get('controlStructureType', '')).upper()
        if c_type in ['IF', 'ELSE', 'WHILE', 'FOR', 'SWITCH', 'BREAK', 'CONTINUE']:
            return JOERN_NODE2ID[c_type]
    return JOERN_NODE2ID.get(label, JOERN_NODE2ID['OTHER'])


def load_joern_neo4jcsv(export_dir):
    all_nodes_dict = {}
    all_edges = []
    for root, dirs, files in os.walk(export_dir):
        for file in files:
            if not file.endswith('.csv') or file.endswith('_header.csv'):
                continue
            data_filepath = os.path.join(root, file)
            header_filepath = data_filepath.replace('_data.csv', '_header.csv')
            try:
                if os.path.exists(header_filepath):
                    with open(header_filepath, 'r', encoding='utf-8', errors='ignore') as hf:
                        headers = next(csv.reader(hf))
                else:
                    with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        headers = next(csv.reader(f))
            except StopIteration:
                continue

            is_edge = ':START_ID' in headers and ':END_ID' in headers
            is_node = ':ID' in headers or 'id' in headers

            clean_headers = []
            for h in headers:
                if h in [':START_ID', ':END_ID', ':ID', ':LABEL', ':TYPE']:
                    clean_headers.append(h)
                else:
                    clean_headers.append(h.split(':')[0].lower() if h else '')

            with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                reader = csv.reader(f)
                if not os.path.exists(header_filepath):
                    next(reader, None)
                for row in reader:
                    if not row or len(row) != len(clean_headers):
                        continue
                    row_dict = dict(zip(clean_headers, row))
                    if is_edge:
                        edge_label = row_dict.get(':TYPE') or row_dict.get('label')
                        if not edge_label:
                            edge_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        if edge_label in VALID_EDGE_LABELS:
                            all_edges.append({'out': row_dict[':START_ID'], 'in': row_dict[':END_ID'], '_label': edge_label})
                    elif is_node:
                        node_id = row_dict.get(':ID') or row_dict.get('id')
                        node_label = row_dict.get(':LABEL') or row_dict.get('label')
                        if not node_label:
                            node_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        row_dict['id'] = node_id
                        row_dict['_label'] = node_label
                        all_nodes_dict[node_id] = row_dict
    return all_nodes_dict, all_edges


def collect_method_subgraph_ids(method_node, ast_children):
    method_id = method_node['id']
    sub_node_ids = set()
    stack = [method_id]
    while stack:
        curr = stack.pop()
        if curr in sub_node_ids:
            continue
        sub_node_ids.add(curr)
        stack.extend(ast_children.get(curr, []))
    return sub_node_ids


def induce_subgraph_from_node_ids(node_ids, all_edges, edge_type=None):
    node_id_set = set(node_ids)
    if edge_type is None:
        sub_edges = [e for e in all_edges if e['_label'] in VALID_EDGE_LABELS and e['out'] in node_id_set and e['in'] in node_id_set]
    else:
        sub_edges = [e for e in all_edges if e['_label'] == edge_type and e['out'] in node_id_set and e['in'] in node_id_set]
    return node_id_set, sub_edges


def materialize_graph_from_ids(sampled_node_ids, sampled_edges, nodes_dict):
    if not sampled_node_ids:
        return {"nodes": [], "edges": [], "texts": []}
    sorted_ids = sorted(list(sampled_node_ids))
    id2idx = {old_id: idx for idx, old_id in enumerate(sorted_ids)}
    nodes_list, texts_list = [], []
    for old_id in sorted_ids:
        node = nodes_dict.get(old_id, {})
        node_label = node.get('_label', 'UNK')
        nodes_list.append(map_joern_node_to_id(node))
        texts_list.append(str(node.get('code') or node.get('name') or node_label))
    EDGE_L2ID = {'AST': 1, 'CFG': 2, 'REACHING_DEF': 3, 'CDG': 4, 'REF': 5}
    edges_list = []
    seen_edges = set()
    for e in sampled_edges:
        u = id2idx[e['out']]
        v = id2idx[e['in']]
        e_type = EDGE_L2ID.get(e['_label'], 1)
        tup = (u, v, e_type)
        if tup not in seen_edges:
            seen_edges.add(tup)
            edges_list.append(list(tup))
    return {"nodes": nodes_list, "edges": edges_list, "texts": texts_list}


def extract_component_relative_path(node_filename, component_prefix):
    path = normalize_path(node_filename)
    low = path.lower()
    cp = component_prefix.lower()
    idx = low.find(cp)
    if idx >= 0:
        return path[idx:].replace("\\", "/")
    return None


def resolve_methods_by_file_for_component(method_nodes, component_prefix, valid_csv_filenames):
    methods_by_file = defaultdict(list)
    unresolved = 0
    basename_to_csv = defaultdict(set)
    valid_list = sorted(valid_csv_filenames)
    for fn in valid_csv_filenames:
        basename_to_csv[normalize_basename(fn)].add(fn)

    for m_node in method_nodes:
        raw_fn = m_node.get("filename", "")
        if not raw_fn:
            unresolved += 1
            continue
        rel = extract_component_relative_path(raw_fn, component_prefix)
        resolved = None
        if rel and rel in valid_csv_filenames:
            resolved = rel
        elif rel:
            suffix_hits = [fn for fn in valid_list if fn.endswith(rel)]
            if len(suffix_hits) == 1:
                resolved = suffix_hits[0]
            elif len(suffix_hits) > 1:
                resolved = sorted(suffix_hits, key=len)[0]
        if resolved is None:
            b = normalize_basename(raw_fn)
            cands = sorted(list(basename_to_csv.get(b, [])))
            if len(cands) == 1:
                resolved = cands[0]
        if resolved is None:
            unresolved += 1
            continue
        methods_by_file[resolved].append(m_node)
    return methods_by_file, unresolved


def choose_best_methods_for_targets(file_methods, target_names):
    chosen = []
    used_ids = set()
    for target in target_names:
        cand = []
        for m in file_methods:
            m_name = str(m.get("name", "")).strip()
            if m_name == target.strip():
                code_len = len(str(m.get("code") or m.get("name") or ""))
                cand.append((code_len, m))
        cand.sort(key=lambda x: (-x[0], str(x[1].get("id"))))
        for _, m in cand:
            if m["id"] not in used_ids:
                chosen.append((target, m))
                used_ids.add(m["id"])
                break
    return chosen


def build_sample_for_method(file_name, method_node, target_name, method_scope_cache, nodes_dict, all_edges):
    func_scope_ids = method_scope_cache[method_node["id"]]
    sample = {
        "filename": file_name,
        "function_name": method_node.get("name", ""),
        "target_name": target_name if target_name is not None else method_node.get("name", ""),
    }

    # mixed local
    func_ids, func_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=None)
    local_graph = materialize_graph_from_ids(func_ids, func_edges, nodes_dict)
    sample["func_nodes"] = local_graph["nodes"]
    sample["func_edges"] = local_graph["edges"]
    sample["func_texts"] = local_graph["texts"]

    # per-edge-type views:
    for et in EDGE_TYPES:
        rel_ids, rel_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=et)
        rel_graph = materialize_graph_from_ids(rel_ids, rel_edges, nodes_dict)
        prefix = f"rel_{et.lower()}"
        sample[f"{prefix}_nodes"] = rel_graph["nodes"]
        sample[f"{prefix}_edges"] = rel_graph["edges"]
        sample[f"{prefix}_texts"] = rel_graph["texts"]

    return sample


def extract_cpg_from_export(export_dir, bin_name, valid_csv_filenames, neg_budget):
    nodes_dict, all_edges = load_joern_neo4jcsv(export_dir)
    method_nodes = [n for n in nodes_dict.values() if n.get('_label') == 'METHOD' and not str(n.get('name', '')).startswith('<')]
    print(f"    [radar]  {len(nodes_dict)} graph node, {len(all_edges)} Core edge connection, {len(method_nodes)} Function Definition")
    if len(method_nodes) == 0:
        return [], []

    component_prefix = get_component_prefix_from_bin(bin_name)
    if component_prefix is None:
        return [], []

    ast_children = {}
    for e in all_edges:
        if e['_label'] == 'AST':
            ast_children.setdefault(e['out'], []).append(e['in'])

    methods_by_file, unresolved = resolve_methods_by_file_for_component(method_nodes, component_prefix, valid_csv_filenames)
    print(f"   component = {component_prefix} | resolved files = {len(methods_by_file)} | unresolved methods = {unresolved}")

    aging_pairs = []
    aging_method_ids = set()
    positive_files = set()
    for target_file, target_funcs in TARGET_AGING_FUNCTIONS.items():
        if not target_file.startswith(component_prefix):
            continue
        file_methods = methods_by_file.get(target_file, [])
        if not file_methods:
            continue
        chosen = choose_best_methods_for_targets(file_methods, target_funcs)
        for target_name, m in chosen:
            aging_pairs.append((target_file, target_name, m))
            aging_method_ids.add(m["id"])
            positive_files.add(target_file)

    print(f"    aging files matched = {len(positive_files)}")
    print(f"    aging function samples = {len(aging_pairs)}")

    neg_candidate_files = [fn for fn in methods_by_file.keys() if fn not in positive_files]
    random.shuffle(neg_candidate_files)
    sampled_neg_files = neg_candidate_files[:neg_budget]
    print(f"    negative candidate files = {len(neg_candidate_files)}")
    print(f"    sampled negative files = {len(sampled_neg_files)}")

    selected_methods = []
    for _, _, m in aging_pairs:
        selected_methods.append(m)
    for fn in sampled_neg_files:
        funcs = methods_by_file.get(fn, [])
        if funcs:
            selected_methods.append(random.choice(funcs))

    method_scope_cache = {}
    for m in selected_methods:
        if m["id"] not in method_scope_cache:
            method_scope_cache[m["id"]] = collect_method_subgraph_ids(m, ast_children)

    extracted_aging = []
    for target_file, target_name, m in aging_pairs:
        extracted_aging.append(build_sample_for_method(target_file, m, target_name, method_scope_cache, nodes_dict, all_edges))

    extracted_non_aging = []
    for fn in sampled_neg_files:
        funcs = methods_by_file.get(fn, [])
        if not funcs:
            continue
        chosen = None
        for m in funcs:
            if m["id"] in method_scope_cache and m["id"] not in aging_method_ids:
                chosen = m
                break
        if chosen is None:
            continue
        extracted_non_aging.append(build_sample_for_method(fn, chosen, None, method_scope_cache, nodes_dict, all_edges))

    print(f"    negative single-function samples = {len(extracted_non_aging)}")
    return extracted_aging, extracted_non_aging

random.seed(5)
np.random.seed(5)

def process_single_bin(bin_path, valid_csv_filenames, neg_budget):
    unique_id = uuid.uuid4().hex[:8]
    tmp_dir = os.path.abspath(f"tmp_netbsd_rel_export_{unique_id}")
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)

    print(f"[Joern] {os.path.basename(bin_path)} ")
    try:
        subprocess.run(
            ["cmd", "/c", JOERN_EXPORT_BAT, bin_path, "--repr", "all", "--format", "neo4jcsv", "--out", tmp_dir],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        graphs_aging, graphs_non_aging = extract_cpg_from_export(tmp_dir, os.path.basename(bin_path), valid_csv_filenames, neg_budget)
    except subprocess.CalledProcessError as e:
        print(f"  ❌ Joern {e.returncode}")
        graphs_aging, graphs_non_aging = [], []
    except Exception as e:
        print(f"  ❌ ！：{e}")
        graphs_aging, graphs_non_aging = [], []
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)
    return graphs_aging, graphs_non_aging


def main():
    valid_csv_filenames = get_valid_csv_filenames(NETBSD_CSV)
    print(f"✅  CSV  {len(valid_csv_filenames)} ")

    bin_files = sorted([f for f in os.listdir(NETBSD_BIN_DIR) if f.endswith(".bin")])
    print(f"🚀  NetBSD ，bin  = {len(bin_files)}")

    PER_BIN_NEG_BUDGET = 20

    aging_data = {}
    non_aging_pool = []

    for f in bin_files:
        bin_path = os.path.join(NETBSD_BIN_DIR, f)
        graphs_aging, graphs_non_aging = process_single_bin(bin_path, valid_csv_filenames, PER_BIN_NEG_BUDGET)

        for idx, g in enumerate(graphs_aging):
            key = f"{g['filename']}__func{idx}__{g['function_name']}"
            aging_data[key] = g
            print(f"  🔥 [] {key} | method={g['function_name']} | local: {len(g['func_nodes'])}")

        for g in graphs_non_aging:
            non_aging_pool.append(g)

    random.shuffle(non_aging_pool)
    target_neg = len(aging_data) * 5
    non_aging_data = {}
    used_neg_files = set()
    for g in non_aging_pool:
        if len(non_aging_data) >= target_neg:
            break
        fn = g["filename"]
        if fn in used_neg_files:
            continue
        used_neg_files.add(fn)
        key = f"{fn}__neg{len(non_aging_data)}__{g['function_name']}"
        non_aging_data[key] = g

    print(f"\n✅  = {len(aging_data)}")
    print(f"✅  = {target_neg}")
    print(f"✅  = {len(non_aging_data)}")

    out_name = "netbsd_joern_multirel_func.pkl"
    with open(out_name, "wb") as f:
        pickle.dump({
            "aging": aging_data,
            "non_aging": non_aging_data,
            "relation_views": [f"rel_{e.lower()}" for e in EDGE_TYPES],
            "variant_note": "function-level local + per-edge-type relation graphs; for AST-backbone residual fusion"
        }, f)

    print(f"\n🎉  {out_name}")
    print("📌 ：")
    print("   - local / func_*")
    for e in EDGE_TYPES:
        print(f"   - rel_{e.lower()}")


if __name__ == "__main__":
    main()
