import os
import csv
import re
import uuid
import pickle
import random
import shutil
import subprocess
import numpy as np
from collections import defaultdict

LINUX_FUNCS = {
    '2.6.4': {
        'drivers/scsi/sym53c8xx_2/sym_glue.c': ['sym53c8xx_queue_command'],
    },
    '2.6.9': {
        'drivers/scsi/aacraid/rkt.c': ['aac_rkt_check_health'],
        'drivers/scsi/aacraid/rx.c': ['aac_rx_check_health'],
    },
    '2.6.12.6': {
        'fs/ext3/balloc.c': ['ext3_try_to_allocate_with_rsv'],
        'fs/ext3/ialloc.c': ['ext3_new_inode'],
        'fs/ext3/inode.c': ['ext3_truncate'],
        'drivers/net/r8169.c': ['rtl8169_rx_vlan_skb'],
    },
    '2.6.38': {
        'net/ipv4/inet_connection_sock.c': ['inet_csk_bind_conflict'],
    }
}

os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-21.0.10"
os.environ["PATH"] = r"C:\Program Files\Java\jdk-21.0.10\bin;" + os.environ["PATH"]
os.environ["JAVA_OPTS"] = "-Xms4G -Xmx8G"

JOERN_EXPORT_BAT = r"D:\joern-cli\joern-export.bat"
LINUX_BIN_DIR = r"D:\linuxbin"
LINUX_CSV = r"D:\linux.csv"

JOERN_NODE2ID = {
    'PAD': 0, 'METHOD': 1, 'METHOD_PARAMETER_IN': 2, 'METHOD_RETURN': 3,
    'BLOCK': 4, 'CALL': 5, 'IDENTIFIER': 6, 'RETURN': 7,
    'LOCAL': 8, 'LITERAL': 9, 'FIELD_IDENTIFIER': 10,
    'TYPE_REF': 11, 'JUMP_TARGET': 12, 'MODIFIER': 13, 'CONTROL_STRUCTURE': 14,
    'IF': 15, 'ELSE': 16, 'WHILE': 17, 'FOR': 18, 'SWITCH': 19, 'BREAK': 20, 'CONTINUE': 21,
    'MEMBER': 22, 'TYPE_DECL': 23, 'OTHER': 99
}

EDGE_TYPES = ['AST', 'CFG', 'REACHING_DEF', 'CDG', 'REF']
VALID_EDGE_LABELS = set(EDGE_TYPES)
EDGE_L2ID = {'AST': 1, 'CFG': 2, 'REACHING_DEF': 3, 'CDG': 4, 'REF': 5}


VERSION_TAG_MAP = {
    "4": "2.6.4",
    "9": "2.6.9",
    "126": "2.6.12.6",
    "27": "2.6.27",
    "38": "2.6.38",
}

LINUX_COMPONENT_PREFIX_MAP = {
    "fs_ext3": "fs/ext3/",
    "fs_jbd": "fs/jbd/",
    "net": "net/",
    "drivers_net": "drivers/net/",
    "drivers_scsi": "drivers/scsi/",
    "include_scsi": "include/scsi/",
}


def normalize_path(s):
    return str(s).replace("\\", "/").strip()


def normalize_basename(s):
    return os.path.basename(normalize_path(s)).lower()


def get_valid_csv_filenames(csv_path):
    valid = set()

    with open(csv_path, 'r', encoding='utf-8-sig', errors='ignore', newline='') as f:
        reader = csv.DictReader(f)

        if reader.fieldnames is None:
            raise ValueError("CSV empty or missing header row")

        raw_fieldnames = reader.fieldnames[:]
        clean_fieldnames = [str(x).strip().replace("\ufeff", "") if x is not None else "" for x in raw_fieldnames]

        print("🔍 raw_fieldnames:", raw_fieldnames)
        print("🔍 clean_fieldnames:", clean_fieldnames)

        filename_col = None
        for raw_name, clean_name in zip(raw_fieldnames, clean_fieldnames):
            if clean_name == "Filename":
                filename_col = raw_name
                break

        if filename_col is None:
            raise ValueError(f"CSV dont have Filename，{clean_fieldnames}")

        for row in reader:
            fn = row.get(filename_col, "")
            fn = normalize_path(fn)
            if fn:
                valid.add(fn)

    return valid


def map_joern_node_to_id(node):
    label = node.get('_label', 'OTHER')
    if label == 'CONTROL_STRUCTURE':
        c_type = str(node.get('controlStructureType', '')).upper()
        if c_type in ['IF', 'ELSE', 'WHILE', 'FOR', 'SWITCH', 'BREAK', 'CONTINUE']:
            return JOERN_NODE2ID[c_type]
    return JOERN_NODE2ID.get(label, JOERN_NODE2ID['OTHER'])


def load_joern_neo4jcsv(export_dir):
    all_nodes_dict = {}
    all_edges = []

    for root, dirs, files in os.walk(export_dir):
        for file in files:
            if not file.endswith('.csv') or file.endswith('_header.csv'):
                continue

            data_filepath = os.path.join(root, file)
            header_filepath = data_filepath.replace('_data.csv', '_header.csv')

            try:
                if os.path.exists(header_filepath):
                    with open(header_filepath, 'r', encoding='utf-8', errors='ignore') as hf:
                        headers = next(csv.reader(hf))
                else:
                    with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        headers = next(csv.reader(f))
            except StopIteration:
                continue

            is_edge = ':START_ID' in headers and ':END_ID' in headers
            is_node = ':ID' in headers or 'id' in headers

            clean_headers = []
            for h in headers:
                if h in [':START_ID', ':END_ID', ':ID', ':LABEL', ':TYPE']:
                    clean_headers.append(h)
                else:
                    clean_headers.append(h.split(':')[0].lower() if h else '')

            with open(data_filepath, 'r', encoding='utf-8', errors='ignore') as f:
                reader = csv.reader(f)
                if not os.path.exists(header_filepath):
                    next(reader, None)

                for row in reader:
                    if not row or len(row) != len(clean_headers):
                        continue

                    row_dict = dict(zip(clean_headers, row))

                    if is_edge:
                        edge_label = row_dict.get(':TYPE') or row_dict.get('label')
                        if not edge_label:
                            edge_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        if edge_label in VALID_EDGE_LABELS:
                            all_edges.append({
                                'out': row_dict[':START_ID'],
                                'in': row_dict[':END_ID'],
                                '_label': edge_label
                            })

                    elif is_node:
                        node_id = row_dict.get(':ID') or row_dict.get('id')
                        node_label = row_dict.get(':LABEL') or row_dict.get('label')
                        if not node_label:
                            node_label = file.split('_')[1] if '_' in file else 'UNKNOWN'
                        row_dict['id'] = node_id
                        row_dict['_label'] = node_label
                        all_nodes_dict[node_id] = row_dict

    return all_nodes_dict, all_edges


def collect_method_subgraph_ids(method_node, ast_children):
    method_id = method_node['id']
    sub_node_ids = set()
    stack = [method_id]

    while stack:
        curr = stack.pop()
        if curr in sub_node_ids:
            continue
        sub_node_ids.add(curr)
        stack.extend(ast_children.get(curr, []))

    return sub_node_ids


def build_local_truncated_node_ids(method_node, ast_children, max_nodes):
    method_id = method_node['id']
    ordered = []
    visited = set()
    stack = [method_id]

    while stack and len(ordered) < max_nodes:
        curr = stack.pop()
        if curr in visited:
            continue
        visited.add(curr)
        ordered.append(curr)

        children = ast_children.get(curr, [])
        for nxt in reversed(children):
            if nxt not in visited:
                stack.append(nxt)

    return set(ordered)


def induce_subgraph_from_node_ids(node_ids, all_edges, edge_type=None):
    node_id_set = set(node_ids)
    if edge_type is None:
        sub_edges = [
            e for e in all_edges
            if e['_label'] in VALID_EDGE_LABELS and e['out'] in node_id_set and e['in'] in node_id_set
        ]
    else:
        sub_edges = [
            e for e in all_edges
            if e['_label'] == edge_type and e['out'] in node_id_set and e['in'] in node_id_set
        ]
    return node_id_set, sub_edges


def materialize_graph_from_ids(sampled_node_ids, sampled_edges, nodes_dict):
    if not sampled_node_ids:
        return {"nodes": [], "edges": [], "texts": []}

    sorted_ids = sorted(list(sampled_node_ids))
    id2idx = {old_id: idx for idx, old_id in enumerate(sorted_ids)}

    nodes_list = []
    texts_list = []
    for old_id in sorted_ids:
        node = nodes_dict.get(old_id, {})
        node_label = node.get('_label', 'UNK')
        nodes_list.append(map_joern_node_to_id(node))
        texts_list.append(str(node.get('code') or node.get('name') or node_label))

    edges_list = []
    seen_edges = set()
    for e in sampled_edges:
        if e['out'] not in id2idx or e['in'] not in id2idx:
            continue
        u = id2idx[e['out']]
        v = id2idx[e['in']]
        e_type = EDGE_L2ID.get(e['_label'], 1)
        tup = (u, v, e_type)
        if tup not in seen_edges:
            seen_edges.add(tup)
            edges_list.append([u, v, e_type])

    return {"nodes": nodes_list, "edges": edges_list, "texts": texts_list}


def extract_component_relative_path(node_filename, component_prefix):
    path = normalize_path(node_filename)
    low = path.lower()
    cp = component_prefix.lower()
    idx = low.find(cp)
    if idx >= 0:
        return path[idx:].replace("\\", "/")
    return None


def parse_linux_bin_meta(bin_name):
    bn = os.path.basename(bin_name).lower()
    if not bn.endswith(".bin"):
        return None, None, None, None

    stem = bn[:-4]
    if not stem.startswith("cpg_"):
        return None, None, None, None

    body = stem[len("cpg_"):]   # drivers_net_4
    m = re.match(r"(.+)_([0-9]+)$", body)
    if not m:
        return None, None, None, None

    component_key = m.group(1)
    version_tag = m.group(2)
    component_prefix = LINUX_COMPONENT_PREFIX_MAP.get(component_key)
    version_str = VERSION_TAG_MAP.get(version_tag)

    return component_key, component_prefix, version_tag, version_str

def normalize_basename(s):
    return os.path.basename(normalize_path(s)).lower()

def resolve_methods_by_file_for_component(method_nodes, component_prefix, valid_csv_filenames):
    methods_by_file = defaultdict(list)
    unresolved = 0

    valid_list = sorted(valid_csv_filenames)

    basename_to_csv = defaultdict(list)
    for fn in valid_list:
        basename_to_csv[normalize_basename(fn)].append(fn)

    for m_node in method_nodes:
        raw_fn = m_node.get("filename", "")
        if not raw_fn:
            unresolved += 1
            continue

        raw_fn_norm = normalize_path(raw_fn)
        rel = extract_component_relative_path(raw_fn_norm, component_prefix)

        resolved = None

        if rel and rel in valid_csv_filenames:
            resolved = rel

        if resolved is None and rel:
            suffix_hits = [fn for fn in valid_list if fn.endswith(rel)]
            if len(suffix_hits) == 1:
                resolved = suffix_hits[0]
            elif len(suffix_hits) > 1:
                suffix_hits = sorted(suffix_hits, key=lambda x: (len(x), x))
                resolved = suffix_hits[0]

        if resolved is None:
            bname = normalize_basename(raw_fn_norm)
            cands = basename_to_csv.get(bname, [])

            if len(cands) == 1:
                resolved = cands[0]
            elif len(cands) > 1:
                comp_cands = [x for x in cands if normalize_path(x).startswith(component_prefix)]
                if len(comp_cands) == 1:
                    resolved = comp_cands[0]
                elif len(comp_cands) > 1:
                    comp_cands = sorted(comp_cands, key=lambda x: (len(x), x))
                    resolved = comp_cands[0]
                else:
                    cands = sorted(cands, key=lambda x: (len(x), x))
                    resolved = cands[0]

        if resolved is None:
            unresolved += 1
            continue

        methods_by_file[resolved].append(m_node)

    return methods_by_file, unresolved

def resolve_target_file(target_file, methods_by_file, component_prefix):
    target_file = normalize_path(target_file)
    all_files = list(methods_by_file.keys())

    if target_file in methods_by_file:
        return target_file

    suffix_hits = [fn for fn in all_files if fn.endswith(target_file)]
    if len(suffix_hits) == 1:
        return suffix_hits[0]
    elif len(suffix_hits) > 1:
        suffix_hits = sorted(suffix_hits, key=lambda x: (len(x), x))
        return suffix_hits[0]

    tb = normalize_basename(target_file)
    base_hits = [fn for fn in all_files if normalize_basename(fn) == tb]
    if len(base_hits) == 1:
        return base_hits[0]
    elif len(base_hits) > 1:
        comp_hits = [fn for fn in base_hits if normalize_path(fn).startswith(component_prefix)]
        if len(comp_hits) == 1:
            return comp_hits[0]
        elif len(comp_hits) > 1:
            comp_hits = sorted(comp_hits, key=lambda x: (len(x), x))
            return comp_hits[0]

        base_hits = sorted(base_hits, key=lambda x: (len(x), x))
        return base_hits[0]

    return None

def choose_best_methods_for_targets(file_methods, target_names, method_scope_cache, nodes_dict, all_edges, min_cfg_edges=2):
    chosen = []
    used_ids = set()

    all_method_names = sorted(set(str(m.get("name", "")).strip() for m in file_methods))

    for target in target_names:
        cand = []
        for m in file_methods:
            m_name = str(m.get("name", "")).strip()
            if m_name != target.strip():
                continue

            mid = m["id"]
            func_scope_ids = method_scope_cache[mid]

            _, cfg_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type="CFG")
            cfg_edge_count = len(cfg_edges)

            code_len = len(str(m.get("code") or m.get("name") or ""))

            cand.append((cfg_edge_count, code_len, m))

        if not cand:
            print(f"      [Objective function miss] {target}")
            print(f"      [Example of optional functions] {all_method_names[:30]}")
            continue

        filtered = [x for x in cand if x[0] >= min_cfg_edges]

        use_cand = filtered if filtered else cand

        use_cand.sort(key=lambda x: (-x[0], -x[1], str(x[2].get("id"))))

        picked = False
        for cfg_edge_count, code_len, m in use_cand:
            if m["id"] not in used_ids:
                chosen.append((target, m))
                used_ids.add(m["id"])
                print(f"      [Hit the objective function] {target} -> {m.get('name')} | cfg_edges={cfg_edge_count} | code_len={code_len}")
                picked = True
                break

        if not picked:
            print(f"      [Objective function not selected] {target}")

    return chosen


def build_sample_for_method(file_name, method_node, target_name,
                            method_scope_cache, local50_cache, local100_cache,
                            nodes_dict, all_edges):
    func_scope_ids = method_scope_cache[method_node["id"]]
    local50_ids = local50_cache[method_node["id"]]
    local100_ids = local100_cache[method_node["id"]]

    sample = {
        "filename": file_name,
        "function_name": method_node.get("name", ""),
        "target_name": target_name if target_name is not None else method_node.get("name", ""),
    }

    func_ids, func_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=None)
    func_graph = materialize_graph_from_ids(func_ids, func_edges, nodes_dict)
    sample["func_nodes"] = func_graph["nodes"]
    sample["func_edges"] = func_graph["edges"]
    sample["func_texts"] = func_graph["texts"]

    sample["cpg_nodes"] = func_graph["nodes"]
    sample["cpg_edges"] = func_graph["edges"]
    sample["cpg_texts"] = func_graph["texts"]

    for et in EDGE_TYPES:
        rel_ids, rel_edges = induce_subgraph_from_node_ids(func_scope_ids, all_edges, edge_type=et)
        rel_graph = materialize_graph_from_ids(rel_ids, rel_edges, nodes_dict)
        prefix = f"rel_{et.lower()}"
        sample[f"{prefix}_nodes"] = rel_graph["nodes"]
        sample[f"{prefix}_edges"] = rel_graph["edges"]
        sample[f"{prefix}_texts"] = rel_graph["texts"]

    sample["cfg_nodes"] = sample["rel_cfg_nodes"]
    sample["cfg_edges"] = sample["rel_cfg_edges"]
    sample["cfg_texts"] = sample["rel_cfg_texts"]

    l50_ids, l50_edges = induce_subgraph_from_node_ids(local50_ids, all_edges, edge_type=None)
    l50_graph = materialize_graph_from_ids(l50_ids, l50_edges, nodes_dict)
    sample["local50_nodes"] = l50_graph["nodes"]
    sample["local50_edges"] = l50_graph["edges"]
    sample["local50_texts"] = l50_graph["texts"]

    l100_ids, l100_edges = induce_subgraph_from_node_ids(local100_ids, all_edges, edge_type=None)
    l100_graph = materialize_graph_from_ids(l100_ids, l100_edges, nodes_dict)
    sample["local100_nodes"] = l100_graph["nodes"]
    sample["local100_edges"] = l100_graph["edges"]
    sample["local100_texts"] = l100_graph["texts"]

    return sample


def extract_linux_cpg_from_export(export_dir, bin_name, valid_csv_filenames, neg_budget):
    nodes_dict, all_edges = load_joern_neo4jcsv(export_dir)
    method_nodes = [
        n for n in nodes_dict.values()
        if n.get('_label') == 'METHOD' and not str(n.get('name', '')).startswith('<')
    ]

    print(f"    [radar]  {len(nodes_dict)} graph node, {len(all_edges)} Core edge connection, {len(method_nodes)} Function Definition")
    if len(method_nodes) == 0:
        return [], []

    component_key, component_prefix, version_tag, version_str = parse_linux_bin_meta(bin_name)
    if component_prefix is None or version_str is None:
        print(f"    {bin_name}")
        return [], []

    print(f"    bin={bin_name} | component={component_key} -> {component_prefix} | version={version_tag} -> {version_str}")

    version_targets = LINUX_FUNCS.get(version_str, {})
    if not version_targets:
        print(f"    {version_str}")
        return [], []

    ast_children = {}
    for e in all_edges:
        if e['_label'] == 'AST':
            ast_children.setdefault(e['out'], []).append(e['in'])

    methods_by_file, unresolved = resolve_methods_by_file_for_component(
        method_nodes, component_prefix, valid_csv_filenames
    )
    print(f"    component = {component_prefix} | resolved files = {len(methods_by_file)} | unresolved methods = {unresolved}")
    method_scope_cache = {}
    for file_methods in methods_by_file.values():
        for m in file_methods:
            mid = m["id"]
            if mid not in method_scope_cache:
                method_scope_cache[mid] = collect_method_subgraph_ids(m, ast_children)
    aging_pairs = []
    aging_method_ids = set()
    positive_files = set()

    for target_file, target_funcs in version_targets.items():
        if not target_file.startswith(component_prefix):
            continue

        print(f"    {target_file} | targets={target_funcs}")

        resolved_target_file = resolve_target_file(target_file, methods_by_file, component_prefix)
        if resolved_target_file is None:
            print(f"    {target_file}")
            continue

        print(f"    {target_file} -> {resolved_target_file}")

        file_methods = methods_by_file.get(resolved_target_file, [])
        if not file_methods:
            print(f"    {target_file} -> {resolved_target_file}")
            continue

        method_names = sorted(set(str(m.get('name', '')).strip() for m in file_methods))
        print(f"    {len(file_methods)}")
        print(f"    {method_names[:20]}")

        chosen = choose_best_methods_for_targets(
            file_methods,
            target_funcs,
            method_scope_cache,
            nodes_dict,
            all_edges,
            min_cfg_edges=2
        )
        for target_name, m in chosen:
            aging_pairs.append((resolved_target_file, target_name, m))
            aging_method_ids.add(m["id"])
            positive_files.add(resolved_target_file)

    print(f"    {len(positive_files)}")
    print(f"    {len(aging_pairs)}")

    positive_basenames = {normalize_basename(fn) for fn in positive_files}

    neg_candidate_files = [
        fn for fn in methods_by_file.keys()
        if fn not in positive_files
           and normalize_basename(fn) not in positive_basenames
    ]

    random.shuffle(neg_candidate_files)
    sampled_neg_files = neg_candidate_files[:neg_budget]

    print(f"    positive basenames = {len(positive_basenames)}")
    print(f"    negative candidate files = {len(neg_candidate_files)}")
    print(f"    sampled negative files = {len(sampled_neg_files)}")

    selected_methods = []
    selected_neg_method_by_file = {}

    for _, _, m in aging_pairs:
        selected_methods.append(m)

    for fn in sampled_neg_files:
        funcs = methods_by_file.get(fn, [])
        if funcs:
            neg_m = random.choice(funcs)
            selected_methods.append(neg_m)
            selected_neg_method_by_file[fn] = neg_m

    local50_cache = {}
    local100_cache = {}

    for file_methods in methods_by_file.values():
        for m in file_methods:
            mid = m["id"]
            if mid not in method_scope_cache:
                method_scope_cache[mid] = collect_method_subgraph_ids(m, ast_children)
            if mid not in local50_cache:
                local50_cache[mid] = build_local_truncated_node_ids(m, ast_children, 50)
            if mid not in local100_cache:
                local100_cache[mid] = build_local_truncated_node_ids(m, ast_children, 100)

    extracted_aging = []
    for target_file, target_name, m in aging_pairs:
        extracted_aging.append(
            build_sample_for_method(
                target_file, m, target_name,
                method_scope_cache, local50_cache, local100_cache,
                nodes_dict, all_edges
            )
        )

    extracted_non_aging = []
    for fn in sampled_neg_files:
        chosen = selected_neg_method_by_file.get(fn)
        if chosen is None:
            continue

        extracted_non_aging.append(
            build_sample_for_method(
                fn, chosen, None,
                method_scope_cache, local50_cache, local100_cache,
                nodes_dict, all_edges
            )
        )

    print(f"    negative single-function samples = {len(extracted_non_aging)}")
    return extracted_aging, extracted_non_aging

random.seed(5)
np.random.seed(5)

def process_single_bin(bin_path, valid_csv_filenames, neg_budget):
    unique_id = uuid.uuid4().hex[:8]
    tmp_dir = os.path.abspath(f"tmp_linux_export_{unique_id}")
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir, ignore_errors=True)

    print(f"[Joern] {os.path.basename(bin_path)}")

    try:
        subprocess.run(
            ["cmd", "/c", JOERN_EXPORT_BAT, bin_path, "--repr", "all", "--format", "neo4jcsv", "--out", tmp_dir],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        graphs_aging, graphs_non_aging = extract_linux_cpg_from_export(
            tmp_dir,
            os.path.basename(bin_path),
            valid_csv_filenames,
            neg_budget
        )

    except subprocess.CalledProcessError as e:
        print(f"  {e.returncode}")
        graphs_aging, graphs_non_aging = [], []
    except Exception as e:
        print(f"  {e}")
        graphs_aging, graphs_non_aging = [], []
    finally:
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return graphs_aging, graphs_non_aging


def main():
    valid_csv_filenames = get_valid_csv_filenames(LINUX_CSV)
    print(f" {len(valid_csv_filenames)} ")

    bin_files = sorted([f for f in os.listdir(LINUX_BIN_DIR) if f.endswith(".bin")])
    print(f"{len(bin_files)}")

    aging_data = {}
    non_aging_pool = []

    PER_BIN_NEG_BUDGET = 20

    for f in bin_files:
        bin_path = os.path.join(LINUX_BIN_DIR, f)
        graphs_aging, graphs_non_aging = process_single_bin(
            bin_path, valid_csv_filenames, PER_BIN_NEG_BUDGET
        )

        for idx, g in enumerate(graphs_aging):
            key = f"{f}__{g['filename']}__func{idx}__{g['function_name']}"
            aging_data[key] = g
            print(
                f"  🔥 [agingfunc] {key} | "
                f"method={g['function_name']} | "
                f"cpg={len(g['cpg_nodes'])} | "
                f"cfg={len(g['cfg_edges'])} | "
                f"local50={len(g['local50_nodes'])} | "
                f"local100={len(g['local100_nodes'])}"
            )

        for g in graphs_non_aging:
            non_aging_pool.append((f, g))

    positive_basenames_global = {
        normalize_basename(g["filename"]) for g in aging_data.values()
    }
    random.shuffle(non_aging_pool)
    target_neg = len(aging_data) * 5
    non_aging_data = {}
    used_neg_files = set()

    for src_bin, g in non_aging_pool:
        if len(non_aging_data) >= target_neg:
            break

        fn = g["filename"]
        base = normalize_basename(fn)

        if base in positive_basenames_global:
            continue

        file_key = f"{src_bin}::{fn}"
        if file_key in used_neg_files:
            continue

        used_neg_files.add(file_key)
        key = f"{src_bin}__{fn}__neg{len(non_aging_data)}__{g['function_name']}"
        non_aging_data[key] = g

    print(f"\n✅ {len(aging_data)}")
    print(f"✅ {target_neg}")
    print(f"✅ {len(non_aging_data)}")

    out_name = "linux_joern_multirel_func.pkl"
    with open(out_name, "wb") as f:
        pickle.dump({
            "aging": aging_data,
            "non_aging": non_aging_data,
            "relation_views": [f"rel_{e.lower()}" for e in EDGE_TYPES],
            "variant_note": "linux function-level local + per-edge-type relation graphs; backward-compatible with func_* / rel_* ; plus cpg/cfg/local50/local100 aliases"
        }, f)

    print(f"\n🎉 {out_name}")
    print("   - cpg_*")
    print("   - cfg_*")
    print("   - local50_*")
    print("   - local100_*")


if __name__ == "__main__":
    main()